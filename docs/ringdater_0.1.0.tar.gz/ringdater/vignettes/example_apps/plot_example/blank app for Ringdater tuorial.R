library(ringdater)

ui <- function(){
    dashboardPage(skin="green",

                  dashboardHeader(title = "RingdateR",
                                  tags$li(class = "dropdown",
                                          tags$style(HTML("
                                        .main-header {max-height: 75px; width = 400px; font-size:40px;}
                                                        .main-header .logo {height: 75px; padding-left = 0px;}
                                                        .sidebar-toggle {height: 75px;
                                                        padding-top: 20px;
                                                        size = 200%;
                                                        background:#FFFFFF;}
                                                        .icon {height: 75px;}

                                                        .navbar {min-height:75px}

                                                        .main-header .logo {
                                                        font-weight: bold;
                                                        font-size: 35px;
                                                        padding-top:15px;
                                                        }

                                                        h1 {color:#FFFFFF}
                                                        h2 {color:#FFFFFF; font-weight: bold; padding:-10,0,0,0}
                                                        h3 {color:#000000;font-size:30px; font-weight: bold; padding:-20,0,0,0}
                                                        h4 {color:#000000;font-size:24px; padding:20,0,0,0}
                                                        h5 {color:#000000;font-size:24px;}
                                                        h6 {color:#000000;font-size:20px;}
                                                        p {color:#000000;font-size:20px;}

                                                        .clearfix {overflow: auto;}

                                                        background{color:#FFFFFF}

                                                        .box.box-solid.box-primary>.box-header {
                                                        color:#fff;
                                                        height:75px;
                                                        padding-top:0px;
                                                        background:#2ca25f
                                                        }

                                                        .box.box-solid.box-primary{
                                                        border-bottom-color:#222d32;
                                                        border-left-color:#222d32;
                                                        border-right-color:#222d32;
                                                        border-top-color:#222d32;
                                                        background:#FFFFFF;
                                                        padding: 0,0,0,0;
                                                        }

                                                        .progress-bar {
                                                        background-color: #2ca25f;
                                                        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.6)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.6)), color-stop(0.75, rgba(255, 255, 255, 0.6)), color-stop(0.75, transparent), to(transparent));
                                                        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        -webkit-background-size: 40px 40px;
                                                        -moz-background-size: 40px 40px;
                                                        -o-background-size: 40px 40px;
                                                        background-size: 40px 40px;
                                                        text.align: center;
                                                        font-size:18px;
                                                        }

                                                        .shiny-notification {
                                                        height: 100px;
                                                        width: 800px;
                                                        position:fixed;
                                                        top: calc(50% - 50px);
                                                        left: calc(50% - 400px);
                                                        font-size:24px;
                                                        }

                                                        .text{color: red;
                                                        font-size: 20px;
                                                        font-style: italic;
                                                        }

                                                        #close{ background-color:#ff8899;}
                                                        #close:hover{background-color:#ff5050; }

                                                        .selectize-input { font-size: 24px; line-height: 28px;}
                                                        .selectize-dropdown { font-size: 24px; line-height: 28px; }

                                                        [type = 'number'] {font-size:30px;
                                                        height:40px;}
                                                        [type = 'text'] {font-size:30px;
                                                        height:40px;}

                                                        input[type=checkbox] {transform: scale(1.5); margin-top:10px;}

                                                        .main-sidebar{width: 230px;}
                                                        .left-side, .main-sidebar {padding-top: 75px;
                                                        padding-left: 10px}
                                                        "))
                                  )
                  ),

                  dashboardSidebar( useShinyjs(),
                                    useShinyalert(),

                                    tags$h2(id = "side_h2_1","Plot options"),
                                    numericInput("text.size", label = h2(id = "side_h2_2","PLot Text size"), value = 12), # changes the plot text size
                                    numericInput("plot.line", label = h2(id = "side_h2_3"," Plotted line thickness"), value = 0.5), # changes the plotted line thickness
                                    numericInput("line.width", label = h2(id = "side_h2_4"," Axis line weighting"), value = 0.5), # Change the axis thickness
                                    tags$hr(),
                                    h2(id = "side_h2_5","Text display settings"),
                                    selectInput("font_select", label = h2(id = "side_h2_6","Select Font size"),
                                                choices = list("Small" = 1, "Medium" = 2, "Large" = 3),
                                                selected = 2)


                  ),
                  dashboardBody(
                      div(id = "form",
                          actionButton("load_data", h4("Load some example data")),
                          div(tableOutput("loaded"), style = "font-size:24px" ),
                          fluidRow(
                              box(width=8, height = 1200,
                                  div(style="text-align: left", actionButton("pw_general_hlp","", icon = icon("info"))),
                                  plotOutput("pairwise_line_plot") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF"),
                                  tags$hr(),
                                  tabsetPanel(
                                      tabPanel(h4(id="pw_rs_h4_1","Check for ring count errors"),
                                               plotOutput("pairwise_hm_small") %>% withSpinner(type = 1, size = 3, color="#2ca25f",  color.background = "#FFFFFF")),
                                      tabPanel(h4(id="pw_rs_h4_2","lead lag results"),
                                               plotOutput("pairwise_lead_lag_bar_plot") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF")))),
                              box(width = 4,
                                  div(style="text-align: right", actionButton("pw_plot_menu_hlp","", icon = icon("info"))),

                                  div(tableOutput("pair_ser_names"), style = "font-size:24px"),
                                  div(tableOutput("single_pair_res"), style = "font-size:24px"),
                                  tabsetPanel(
                                      tabPanel(h4(id="pw_rs_h4_3","Sample selection"),
                                               selectInput("pairwise_selec_method", label = h4(id="pw_rs_h4_4","Selection options"), choices = list("Manually choose samples" = 1, "Select row from results table" = 2), selected = 1),
                                               selectInput("pairwise_series_1", label = h4(id="pw_rs_h4_5","Manually select first series"), h4(c(""))),
                                               selectInput("pairwise_series_2", label = h4(id="pw_rs_h4_6","Manually select second series"), h4(c(""))),
                                               selectInput("auto_lag", label = h4(id="pw_rs_h4_7","Select lag"),choices = list("Best match" = 1, "Second best" = 2, "Third best" = 3, "Custom lag" = 4), selected = 1),
                                               numericInput("PS_2_lag", h4(id="pw_rs_h4_8","Enter value for custom lag"), value =0)),
                                      tabPanel(h4(id="pw_rs_h4_9","Plot options"),
                                               checkboxInput("pair_line_stand", h4(id="pw_rs_h4_10","Normalise the data in the plot"), F),
                                               selectInput("pairwise_colour_scale", label = h4(id="pw_rs_h4_11","Select colour scale"),choices = list("Blue-Grey-Red" = 1, "Grey-Red" = 2, "Grey-Blue" = 3, "White-Black" = 4), selected = 1),
                                               checkboxInput("adjust_pair_lineX", h4(id="pw_rs_h4_12","adjust x axis scale line plot"), F),
                                               numericInput("Pairwise_line_X_max", h4(id="pw_rs_h4_13","Max X axis value"), value =""),
                                               numericInput("Pairwise_line_X_min", h4(id="pw_rs_h4_14","Min X axis value"), value = ""))
                                  ),
                                  downloadButton("pair_plot_download", h4(id="pw_rs_h4_15","Save the line plot")),
                                  downloadButton("pair_small_hm_downlaod", h4(id="pw_rs_h4_16","Save the heat map")),
                                  downloadButton("pair_bar_plot_download", h4(id="pw_rs_h4_17","Save the bar graph"))

                              )),

                          fluidRow(
                              box(width=3, title = h4(id="pw_rs_h4_18","Step 1: Filter results by statistics"),
                                  div(style="text-align: right", actionButton("pw_stat_filt_hlp","", icon = icon("info"))),
                                  checkboxInput("filter_3_check", h4(id="pw_rs_h4_19","Filter by stats"), F),
                                  numericInput("pair_r", h4(id="pw_rs_h4_20","R value"), value = 0.50),
                                  numericInput("pair_sig", h4(id="pw_rs_h4_21","Significance value"), value =0.01),
                                  numericInput("pair_overlap", h4(id="pw_rs_h4_22","Overlap"), value =50)
                              ),
                              box(width=3, title = h4(id="pw_rs_h4_23","Step 2: Filter results by series name"),
                                  div(style="text-align: right", actionButton("pw_name_filt_hlp","", icon = icon("info"))),
                                  checkboxInput("filter_1_check", h4(id="pw_rs_h4_24","Select target sample/filter table by sample"), F),
                                  selectInput("pairwise_filter_1", label = h4(""), c("")),
                                  checkboxInput("filter_2_check", h4(id="pw_rs_h4_25","Filter using Series 2"), F),
                                  selectInput("pairwise_filter_2", label = h4(""), c(""))
                              ),
                              box(width = 3, title = h4(id="pw_rs_h4_26","Step 3: Check for Problematic Samples"),
                                  div(style="text-align: right", actionButton("pw_prob_ck_hlp","", icon = icon("info"))),
                                  numericInput("pair_prob_samp_wind", h4(id="pw_rs_h4_27","Set window to evaluate for problem samples (Years, must be even)"), value =20),
                                  actionButton("prob_samp_check", h4(id="pw_rs_h4_28","Check for problematic samples")),
                                  div(tableOutput("pairwise_prob_samples"), style = "font-size:24px")

                              ),
                              box(width = 3,
                                  title = h4(id="pw_rs_h4_29","Step 4: Align samples"),
                                  div(style="text-align: right", actionButton("pw_align_hlp","", icon = icon("info"))),
                                  selectInput("align_all_pair", h4(id="pw_rs_h4_30","Series selection method"), choices = list("All series" = 1, "All series, excluding problem samples" = 2, "Manual sample selection" =3), selected = 1),
                                  h4(id="pw_rs_h4_31","Manual sample selection"),
                                  selectInput("align_ser_select", h4(id="pw_rs_h4_32","Manual sample selection"), label = c(""), multiple = T),
                                  actionButton("Go_initiate_chrono", h4(id="pw_rs_h4_33","Align selected data"))

                              )

                          ),
                          fluidRow(
                              box(width=12,downloadButton("pairwise_res_download", h4(id="pw_rs_h4_35","Download results table")),
                                  div(DT::dataTableOutput("pairwise_res_table"), style = "font-size:24px"))
                          )
                      )))}

shinyServer <- function(input, output, session) {

    addClass(selector = "body", class = "sidebar-collapse")

    example_data <- reactiveValues(df_data = data.frame(NULL))

    observeEvent(input$load_data,{
        example_data$df_data<-read.csv("example_data/dated_example.csv", stringsAsFactors = FALSE, header = TRUE)

    })

    output$loaded<-renderTable(if (nrow(example_data$df_data)>1){data.frame(DATA ="Data loaded - Now choose settings and Produce the heat map")
        } else {NULL} )


    gen_plot<-eventReactive(input$go2,{
        if (nrow(example_data$df_data)<1){NULL
            } else {
        req(example_data$df_data)
        req(input$sing_first_series)
        req(input$sing_second_series)
                           }
        })

    output$example_plot<-renderPlot({
        gen_plot()
        }, height = 900, res = 120)
}

# Run the application
shinyApp(ui = ui, server = shinyServer)
