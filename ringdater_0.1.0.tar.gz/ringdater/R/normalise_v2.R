#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' normalise()
normalise<-function(the.data = the.data, detrending_select = 1, splinewindow = 21, PT = FALSE, AR_mod = F){
  series_data<-the.data
  no.series<-ncol(the.data)-1
  series_IDs<-c(colnames(the.data))
  series_a<-2 # this is two as the first set of series data should be in the second column
  new<-data.frame(the.data[,1], stringsAsFactors = T) # sets up the data frame to put the detrended data into


#  if (logT == TRUE){logged_data<-log(the.data[,-1])
#  series_data<-cbind(the.data[,1], logged_data)
#  }

  if (PT == TRUE){
    series_data <- powt(series_data)
  }

  if (AR_mod == T){
  for(i in 1:no.series){
    A<- detrend.series(series_data[,series_a], method = "Ar", make.plot = F, pos.slope =T)
    new <- cbind(new, A)
    series_a<-series_a+1
    }
  series_data<-new
  }

  series_a<-2
  tmp_diff<-c()
  det_tmp<-data.frame(the.data[,1])

  for(i in 1:no.series){ # this runs the detrending on all the series data
    if(detrending_select==1){
      A<- series_data[,series_a]
    } else if (detrending_select==2){
      A<- scale(series_data[,series_a], center = T, scale = T)
    } else if (detrending_select==3){
      A<- detrend.series(series_data[,series_a], method = "Spline", nyrs= splinewindow, make.plot = F, pos.slope =T)
    } else if (detrending_select==4){
      A<- detrend.series(series_data[,series_a], method = "ModNegExp", make.plot = F, pos.slope =T)
    } else if (detrending_select==5){
      A<- detrend.series(series_data[,series_a], method = "Friedman", make.plot = F, pos.slope =T)
    } else if (detrending_select==6){
      A<- detrend.series(series_data[,series_a], method = "ModHugershoff", make.plot = F, pos.slope =T)
    } else if (detrending_select==7){
      A<- series_data[,series_a]
      for (j in 1: length(A)){
        tmp<-A[j+1]-A[j]
        tmp_diff<-c(tmp_diff,tmp)
      }
      A<-tmp_diff
      tmp_diff<-c()
    }


    det_tmp<-cbind.fill(det_tmp, A, fill = NA)
    series_a<-series_a+1
  }

  series_length = nrow(new)

  det_tmp<-subset(det_tmp, !is.na(det_tmp[,1]))

  colnames(det_tmp)<-series_IDs

  return(det_tmp)
}
