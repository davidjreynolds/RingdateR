#' Run RingdateR
#'
#' This function actually runs RingdateR
#' @keywords GUI
#' @export
#' @examples
#' run_ringdater()
run_ringdater<-function(){
  options(shiny.maxRequestSize = 50*1024^2)
  doParallel::registerDoParallel(cores=2)
  shinyApp(ui = ui, server = shinyServer)
}
