#' Theme for plots in RingdateR
#'
#' Modify the theme used in the plots displ;ayed in RingdateR
#' @keywords GUI
#' @param text.size A numeric integer to define the size of the text displayed in the figures
#' @param line.width A numeric integer to set the width of the axis lines.
#' @param leg_size A numeric integer to set the size of the colour legends in the heat map plots.
#' @export
#' @examples
#' R_dateR_theme()
R_dateR_theme<-function(text.size = 12, line.width = 1, l = 10, leg_size = 3){

   theme(
  text = element_text(size = text.size),
  panel.background = element_blank(),

  axis.line = element_line(size = line.width,
                           colour = "black"),
  axis.ticks = element_line(colour = "black",
                            size = line.width),
  axis.text = element_text(size = text.size,
                           color = "black"),
  axis.ticks.length = unit(.25, "cm"),
  plot.margin = margin(10, 0, 0, l), #T,R,B,L
  axis.title.y = element_text(size = text.size,
                              margin=margin(t= 0, r = 20, b =10, l = )),
  legend.key = element_rect(size = 10),
  panel.grid.major = element_line(colour = "grey",
                                  size = 0.5,
                                  linetype = "dashed"),
  legend.position="bottom",
  legend.text = element_text(size = text.size),
  legend.key.width = unit(leg_size,"cm")
  )
  }
