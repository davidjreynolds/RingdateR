

run_ringdater<-function(){
  options(shiny.maxRequestSize = 50*1024^2)
  registerDoParallel(cores=2)
  runApp(list(ui = ui, server = RingServer), launch.browser = TRUE)
}
