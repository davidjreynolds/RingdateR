

load_chron<- function(file){

  file_detect<-function(x,n){
    substr(x, nchar(x)-n+1, nchar(x))
  }

  # Detect the file format
  ftype<-file_detect(file,3)

  acc_ftypes <- c("rwl", "csv", "lsx", "txt")
  if (!ftype %in% acc_ftypes){
    stop(paste0("Error in load_chron: File type is not supported\n
    Problem file: ",file))
  }

  if(ftype=="rwl"){
   chron_loading_df_data<-read.rwl(file)
   chron_loading_df_data <- as.data.frame(chron_loading$df_data)
   chron_loading_df_data <- cbind.data.frame(as.numeric(row.names(chron_loading$df_data)),chron_loading$df_data)
    row.names(chron_loading$df_data)<-c()
  } else if (ftype=="csv"){
   chron_loading_df_data<-read.csv(file, header = TRUE, stringsAsFactors = FALSE)
  } else if (ftype=="lsx"){
   chron_loading_df_data<-as.data.frame(read_excel(file, sheet = 1, na ="NA" ))
  } else if (ftype=="txt"){
   chron_loading_df_data<-read.csv(file, header = TRUE, sep = "/t", stringsAsFactors = FALSE)
  }
  chron_loading_df_data<-name_check(chron_loading_df_data)

  return(chron_loading_df_data)
}
