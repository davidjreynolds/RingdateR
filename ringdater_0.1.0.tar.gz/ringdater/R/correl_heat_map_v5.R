#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' correl_heat_map()
correl_heat_map<-function(the.data = the.data, s1 = 2, s2 = 2, neg_lag = -10, pos_lag = 10, N_limit = 21, win = 21, complete=F){

  new<-the.data

  a<-new[s1]
  b<-new[s2]

  new<-data.frame(new[,1],a,b, stringsAsFactors = T)
  colnames(new)<-c("years","A","B")
  shell_ID<-colnames(the.data)

  N_limit<-win
  win<-win
  ###########################################################

  run_cor_res<-data.frame()

  #extract the data for the analysis
  years<-new[,1]
  shell_a<-new[,2]
  shell_b<-new[,3]
  run.cor.dat<-data.frame(years,shell_a,shell_b)

  ser_a_len<-length(subset(shell_a, (!is.na(shell_a))))
  ser_b_len<-length(subset(shell_b, (!is.na(shell_b))))

  #pos_lag_lim<-length(subset(shell_a, (!is.na(shell_a))))-N_limit
  #neg_lag_lim<--length(subset(shell_b, (!is.na(shell_b))))+N_limit-100
  pos_lag_lim<- max(c(ser_a_len,ser_b_len))
  neg_lag_lim<- -max(c(ser_a_len,ser_b_len))

  if(complete){pos_lag<-pos_lag_lim   # tells the analysis to run over the maximum allowable lead-lag
  neg_lag<-neg_lag_lim}

  if (pos_lag>pos_lag_lim){max_pos_lag<-pos_lag_lim
  } else {max_pos_lag<-pos_lag}

  if (neg_lag<neg_lag_lim){max_neg_lag<-neg_lag_lim
  } else {max_neg_lag<-neg_lag}

  # set up the data for the analysis

   lag<-max_neg_lag

repeat {
    if(lag<=-1){
      NA_ser<-rep(NA,abs(lag))
      yr_mod<-c(NA_ser,years)
      mod_ser_1<-c(NA_ser,shell_a)
      mod_ser_2<-c(shell_b,NA_ser)
      analysis.data<-cbind.fill(yr_mod,mod_ser_1,mod_ser_2, fill = NA)
    } else if (lag==0){
      yr_mod<-years
      mod_ser_1<-shell_a
      mod_ser_2<-shell_b
      analysis.data<-cbind.fill(yr_mod,mod_ser_1,mod_ser_2, fill = NA)
    } else if(lag>=1){
      NA_ser<-rep(NA,lag)
      yr_mod<-c(years,NA_ser)
      mod_ser_1<-c(shell_a,NA_ser)
      mod_ser_2<-c(NA_ser,shell_b)
      analysis.data<-cbind.fill(yr_mod,mod_ser_1,mod_ser_2, fill = NA)
    }

    len_test<-subset(analysis.data, complete.cases(analysis.data))
    analysis.data<-subset(analysis.data, complete.cases(analysis.data))

    if(nrow(analysis.data)<=win){NULL

    } else {
      cor_test<-rollcor(analysis.data[,2],analysis.data[,3], width = win, show =F)
      cor_year<-rollmean(analysis.data[,1], k = win)
      lag_ser<- rep(lag,length(cor_year))

    run_cor_tmp<-cbind.fill(cor_year, lag_ser, cor_test, fill = NA)
    run_cor_tmp<-subset(run_cor_tmp, complete.cases(run_cor_tmp))
    colnames(run_cor_tmp)<-c("year", "lag", "R val")

    run_cor_res<-rbind(run_cor_res,run_cor_tmp)
    colnames(run_cor_res)<-c("year", "lag", "R val")

    mod_ser_1<-NULL
    mod_ser_2<-NULL
  }
  if (lag>=max_pos_lag){break}
  lag<-lag+1


}
  # run_cor_res<-subset(run_cor_res, complete.cases(run_cor_res))
   if(nrow(run_cor_res)<5){run_cor_res<-NULL}
  return(run_cor_res)

}
