#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' correl_replace()
correl_replace<-function(the.data = the.data){
  ser<-2
  ser.names<-colnames(the.data)
  colhead<-c("Series ID", "First Ring", "Last ring","R value","P value","Overlap with chronology")
  results<-data.frame()

  for (i in 1:(ncol(the.data)-1)){
    series<-the.data[,ser]
    sub<-the.data[,-ser]

    chron_mean<-rowMeans(sub[,-1], na.rm = T)
    comb<-data.frame(the.data[,1],series,chron_mean)

    just_ser<-data.frame(the.data[,1],series)

    just_ser<-subset(just_ser,complete.cases(just_ser))
    comb<-subset(comb,complete.cases(comb))

    cor_test<-cor.test(series,chron_mean)

    p_val<-cor_test$p.value
    r_val<-cor_test$estimate
    over<-nrow(comb)

    first<-min(just_ser[,1])
    last<-max(just_ser[,1])

    tmp<-data.frame(ser.names[ser],first,last,r_val,p_val,over)
    colnames(tmp)<-colhead
    results<-rbind(results,tmp)
    ser<-ser+1

  }

    colnames(results)<-colhead
    return(results)
}
