#' Perform running leead-lag analysis and produce a heatmap
#'
#' This function performs running lead-lag analysis and produces a heatmap plot of the results
#' @keywords crossdating
#' @param the_data A dataframe containing the timeseries to be comapred. First column must contain dates.
#' @param samp1 An integer relating to the column number of a sample to be analysed
#' @param samp2 An integer relating to the column number of a sample to be analysed
#' @param neg_lag An integer to define the lower lag limit. Does not have to be negative.
#' @param pos_lag An integer to define the upper lag limit. Must be greater than neg_lag, but can be negative.
#' @param win An integer that defines the window that the running correlations are calculated over. Must be odd.
#' @param complete True/False defines whether the lead-lag analyses are conducted over the maximum range of leads and lags between the two selected samples
#' @param col_sel An integer relating to the colours to be used in the plot.
#' @export
#' @examples heatmap_analysis(the_data = the_data, samp1 = 2, samp2 = 3, complete = FALSE)
#' heatmap_analysis()
heatmap_analysis<-function(the_data, samp1, samp2, neg_lag = -20, pos_lag = 20, win = 21, complete = TRUE, col_sel = 1){

  plot.data<-running_lead_lag(the_data, colnames(the_data)[samp1], colnames(the_data)[samp2], neg_lag = neg_lag, pos_lag = pos_lag, win = win, complete = complete)

  col_scale <- col_pal(col_sel)

  x.lab<-colnames(the_data)[1]

  y.lab<-paste0("Lag (years from sample/n",colnames(the_data)[samp1])

  plot1<-ggplot(plot.data, aes(x=plot.data[,1], y=plot.data[,2]), na.rm=TRUE) + geom_raster(aes(fill = plot.data[,3])) + R_dateR_theme(text.size = 12, leg_size = 2) +
    scale_fill_gradientn(colours = col_scale, limits = c(-1,1)) +labs(fill = "Correl. (R)", x = x.lab, y= y.lab) +
    scale_x_continuous(breaks = x.scale.bar(round(min(plot.data[,1]),-1), round(max(plot.data[,1]),-1))) +
    scale_y_continuous(breaks = y.scale.bar(min(plot.data[,2]),max(plot.data[,2])))
return(plot1)
}

