#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' y.scale.bar()
y.scale.bar<-function(y.min,y.may){

if(y.may-y.min>1000){
  breaks<-seq(y.min, y.may, by = 100)
}  else if(y.may-y.min>500){
   breaks<-seq(y.min, y.may, by = 50)
   } else if(y.may-y.min>250){
     breaks<-seq(y.min, y.may, by = 20)
   } else if (y.may-y.min>50){
     breaks<-seq(y.min, y.may, by = 10)
   } else if (y.may-y.min>20){
     breaks<-seq(y.min, y.may, by = 5)
   } else{breaks<-seq(y.min, y.may, by = 2) }

return(breaks)
}
