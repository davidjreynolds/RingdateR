ui <- function(){
  dashboardPage(skin="green",

                dashboardHeader(title = "RingdateR",
                                tags$li(class = "dropdown",
                                        tags$style(HTML("
                                        .main-header {max-height: 75px; width = 400px; font-size:40px;}
                                                        .main-header .logo {height: 75px; padding-left = 0px;}
                                                        .sidebar-toggle {height: 75px;
                                                        padding-top: 20px;
                                                        size = 200%;
                                                        background:#FFFFFF;}
                                                        .icon {height: 75px;}

                                                        .navbar {min-height:75px}

                                                        .main-header .logo {
                                                        font-weight: bold;
                                                        font-size: 35px;
                                                        padding-top:15px;
                                                        }

                                                        h1 {color:#FFFFFF}
                                                        h2 {color:#FFFFFF; font-weight: bold; padding:-10,0,0,0}
                                                        h3 {color:#000000;font-size:30px; font-weight: bold; padding:-20,0,0,0}
                                                        h4 {color:#000000;font-size:24px; padding:50,0,0,0}
                                                        h5 {color:#000000;font-size:24px;}
                                                        h6 {color:#000000;font-size:20px;}
                                                        p {color:#000000;font-size:20px;}

                                                        .clearfix {overflow: auto;}

                                                        background{color:#FFFFFF}

                                                        .box.box-solid.box-primary>.box-header {
                                                        color:#fff;
                                                        height:75px;
                                                        padding-top:0px;
                                                        background:#2ca25f
                                                        }

                                                        .box.box-solid.box-primary{
                                                        border-bottom-color:#222d32;
                                                        border-left-color:#222d32;
                                                        border-right-color:#222d32;
                                                        border-top-color:#222d32;
                                                        background:#FFFFFF;
                                                        padding: 0,0,0,0;
                                                        }

                                                        .progress-bar {
                                                        background-color: #2ca25f;
                                                        background-image: -webkit-gradient(linear, 0 100%, 100% 0, color-stop(0.25, rgba(255, 255, 255, 0.6)), color-stop(0.25, transparent), color-stop(0.5, transparent), color-stop(0.5, rgba(255, 255, 255, 0.6)), color-stop(0.75, rgba(255, 255, 255, 0.6)), color-stop(0.75, transparent), to(transparent));
                                                        background-image: -webkit-linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        background-image: -moz-linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        background-image: -o-linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.6) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.6) 50%, rgba(255, 255, 255, 0.6) 75%, transparent 75%, transparent);
                                                        -webkit-background-size: 40px 40px;
                                                        -moz-background-size: 40px 40px;
                                                        -o-background-size: 40px 40px;
                                                        background-size: 40px 40px;
                                                        text.align: center;
                                                        font-size:18px;
                                                        }

                                                        .shiny-notification {
                                                        height: 100px;
                                                        width: 800px;
                                                        position:fixed;
                                                        top: calc(50% - 50px);
                                                        left: calc(50% - 400px);
                                                        font-size:24px;
                                                        }

                                                        .text{color: red;
                                                        font-size: 20px;
                                                        font-style: italic;
                                                        }

                                                        #close{ background-color:#ff8899;}
                                                        #close:hover{background-color:#ff5050; }

                                                        .selectize-input { font-size: 24px; line-height: 28px;}
                                                        .selectize-dropdown { font-size: 24px; line-height: 28px; }

                                                        [type = 'number'] {font-size:30px;
                                                        height:40px;}
                                                        [type = 'text'] {font-size:30px;
                                                        height:40px;}

                                                        input[type=checkbox] {transform: scale(1.5); margin-top:10px;}

                                                        .main-sidebar{width: 230px;}
                                                        .left-side, .main-sidebar {padding-top: 75px;
                                                        padding-left: 10px}
                                                        "))
                                )
                ),

                dashboardSidebar( useShinyjs(),
                                  useShinyalert(),

                                  tags$h2(id = "side_h2_1","Plot options"),
                                  numericInput("text.size", label = h2(id = "side_h2_2","PLot Text size"), value = 12), # changes the plot text size
                                  numericInput("plot.line", label = h2(id = "side_h2_3"," Plotted line thickness"), value = 0.5), # changes the plotted line thickness
                                  numericInput("line.width", label = h2(id = "side_h2_4"," Axis line weighting"), value = 0.5), # Change the axis thickness
                                  tags$hr(),
                                  h2(id = "side_h2_5","Text display settings"),
                                  selectInput("font_select", label = h2(id = "side_h2_6","Select Font size"),
                                              choices = list("Small" = 1, "Medium" = 2, "Large" = 3),
                                              selected = 2)


                ),
                dashboardBody(
                  div(id = "form",
                      tabsetPanel(id = "navbar",
                                  tabPanel(h4(id = "nav_h4_1", "Starting point"), value ="starting",
                                           fluidRow(box(width=10, height = "100px", title = h3(id = "st_pt_h3_1", "Welcome to RingdateR (V1 beta)", actionButton("st_general_hlp", h6("I - Quick Help/about")))),

                                                    div(style = "text-align: center; font-size:18px",
                                                        actionButton("close",label = tags$b(p("Stop RingdateR. Returns to launcher")), icon = icon("fas fa-skull fa-2x"), onclick = "setTimeout(function(){window.close();},500);",
                                                                     style ="white-space: normal;
                                                                              width: 250px;


                                                                              "))),


                                           fluidRow(column(3,
                                                           box(width = NULL, title = h2(id = "st_pt_h2_1", "Step 1: Analysis options"), status = "primary",
                                                               div(style="text-align: right", actionButton("st_analysis_hlp","", icon = icon("info"))),
                                                               solidHeader = TRUE,
                                                               align="left",
                                                               selectInput("detrending_select", h4(id = "st_pt_h4_1", "Choose a detrending method"),
                                                                           choices = list("Do nothing to my data" = 1,
                                                                                          "Convert to z-scores" = 2,
                                                                                          "Spline detrending" = 3,
                                                                                          "Mod. negative exponential" = 4,
                                                                                          "Friedman" = 5,
                                                                                          "ModHugershoff" = 6,
                                                                                          "First difference" = 7
                                                                           ), selected = 3),
                                                               # checkboxInput("diff", h4(id = "st_pt_h4_3", "Detrend by subtraction?"), F),
                                                               numericInput("splinewindow", h4(id = "st_pt_h4_2", "Select a spline window (only applies to spline detrendning option)"), value = 21, min = 5, max = 200),
                                                               #  checkboxInput("PT", h4(id = "st_pt_h4_3", " Power Transform data?"), F),
                                                               checkboxInput("total_overlap", h4(id = "st_pt_h4_4", "Automatically set lag limits? (uses all possible leads/lags)"), FALSE),
                                                               h6(id = "st_pt_h6_1", "Alternatively set limits for lead-lag range"),
                                                               numericInput("neg_lag",h4(id = "st_pt_h4_5", "Select negative lag (years)"), min = 0, value =-20),
                                                               numericInput("pos_lag", h4(id = "st_pt_h4_6", "Select positive lag (years)"), min = 0, value =20),
                                                               numericInput("cor_win", h4(id = "st_pt_h4_7", "Select correlation window (years)"), min = 5, value =21),
                                                               h6(id = "st_pt_h6_2","Correlation window needs to be an odd number. Even numbers will be converted to odd by adding 1."))),
                                                    column(3,
                                                           box(width = NULL, status = "primary",
                                                               solidHeader = TRUE,
                                                               title = h2(id = "st_pt_h2_2","Step 2: Load undated series"),
                                                               div(style="text-align: right", actionButton("st_undate_hlp","", icon = icon("info"))),
                                                               selectInput("multi_chron", h4(id = "st_pt_h4_8","What type of undated data do you want to load?"), choices = list("Load individual undated series (.csv, .pos, .lps, .rwl, .txt, .xlsx)" = 1, "Load undated chronologies (.rwl, .csv, .xlsx)" = 2), selected = 1),
                                                               fileInput('file1', h4(id = "st_pt__h4_9",'Load data for pairwise analysis'), multiple = TRUE, buttonLabel = h6("Select a file"), placeholder = "No file selected",
                                                                         accept=c('text/csv', 'text/comma-separated- values,text/plain', '.csv', '.pos', '.lps', '.rwl', '.txt', '.xlsx')),
                                                               tags$hr(),
                                                               checkboxInput("pair_detrend", h4(id = "st_pt_h4_10", "Apply detrending"), T),
                                                               selectInput("year_inc_select", h4(id = "st_pt_h4_11", "First column is years or increment count?"), choices = list("Years" = 1, "Increment count" = 2), selected = 1),
                                                               tags$hr()

                                                           ),

                                                           box( width = NULL, status = "primary",
                                                                solidHeader = TRUE,
                                                                title = h2(id = "st_pt_h2_3","Load a dated chronology"),
                                                                div(style="text-align: right", actionButton("st_chron_hlp","", icon = icon("info"))),
                                                                fileInput('file2', h4(id = "st_pt_h4_12", 'Load chronology data (.rwl, .csv, .xlsx).'), multiple = FALSE, buttonLabel = h6("Select a file"), placeholder = "No file selected",
                                                                          accept=c('text/csv', 'text/comma-separated- values,text/plain', '.csv', '.rwl', '.xlsx')),
                                                                #checkboxInput("master_chron_load", h4("Is this a master chronology (two column format: year, detrended mean chronology)?"), F),
                                                                checkboxInput("chron_detrend", h4(id = "st_pt_h4_13", "Apply detrending"), T)


                                                           ),
                                                           box( width = NULL, status = "primary",
                                                                solidHeader = TRUE,
                                                                title = h2(id = "st_pt_h2_4","Use example data"),
                                                                div(style="text-align: right", actionButton("st_example_hlp","", icon = icon("info"))),
                                                                actionButton("example_undated", h4(id = "st_pt_h4_14", "Use example dated and undated series")))
                                                    ),
                                                    column(3,
                                                           box( width = NULL, title = h2(id = "st_pt_h2_5","Step 3: Series to analyse"), status = "primary",
                                                                solidHeader = TRUE,
                                                                div(style="text-align: right", actionButton("st_clear_data_hlp","", icon = icon("info"))),
                                                                actionButton("Go_clear_loaded", h4(id = "st_pt_h4_15","Clear all loaded data")),
                                                                plotOutput("load_plot", height = "10%") %>% withSpinner(type = 1, size = 2, color="#2ca25f", color.background = "#FFFFFF"),
                                                                div(tableOutput("analysis.data.out"), style = "font-size:24px" ))
                                                    ),
                                                    tags$script('
    Shiny.addCustomMessageHandler("resetFileInputHandler", function(x) {
        var id = "#" + x + "_progress";
        var idBar = id + " .bar";
        $(id).css("visibility", "hidden");
        $(idBar).css("width", "0%");
    });
  '),
                                                    column(3,
                                                           box( width = NULL, title = h2(id = "st_pt_h2_6","Step 4: Choose analysis pathway"), status = "primary",
                                                                solidHeader = TRUE,
                                                                selectInput("mode_select", label = h3("Choose analysis pathway"), choices = list("Pairwise Anlysis Mode"=1, "Chronology Analysis Mode"=2), selected = 2),
                                                                actionButton("Go_pairwise_no", h4(id = "st_pt_h4_17","Run the analyses"), icon = icon("rocket"))
                                                           )
                                                    ))),

                                  ###################################################################

                                  tabPanel(h4(id = "nav_h4_2", "Loaded Data"), value="loaded",
                                           tabsetPanel(
                                             tabPanel(h4("Undated series"), value ="mand",
                                                      fluidRow(box(width=12,
                                                                   div(tableOutput("undated_data_table"), style = "font-size:24px")))),
                                             tabPanel(h4("Chronology data"), value ="chrono",
                                                      div(tableOutput("loaded_chronology_data_table"), style = "font-size:24px")),

                                             tabPanel(h4("Detrended data"), value ="mand",
                                                      downloadButton('download_detrend',label=h4(id = "ld_dt_h4_1","Save the detrended series (as .CSV)")),
                                                      div(tableOutput("detrended_data_table"), style = "font-size:24px")),

                                             # This can be used to show other data
                                             tabPanel(h4("debug"), value ="mand",
                                                      div(tableOutput("debug"), style = "font-size:24px"),
                                                      div(tableOutput("debug2"), style = "font-size:24px"))

                                           )
                                  ),

                                  tabPanel(h4(id = "nav_h4_3", "Detrending Plot"), value ="detrending",
                                           fluidRow(
                                             box(width=9,
                                                 plotOutput("detrending.plot.out", height = "100%")
                                             ),
                                             box(width=3,
                                                 downloadButton('downloadsingplt',label=h4(id="dt_plt_h4_1","Download plot as png")),
                                                 selectInput("first_series", label = h4(id="dt_plt_h4_2","Select first series"), c(""))
                                             )
                                           )),

                                  tabPanel(h4(id = "nav_h4_4", "Results"), value ="pairwise",

                                           fluidRow(
                                             box(width=8, height = 1200,
                                                 div(style="text-align: left", actionButton("pw_general_hlp","", icon = icon("info"))),
                                                 plotOutput("pairwise_line_plot") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF"),
                                                 tags$hr(),
                                                 tabsetPanel(
                                                   tabPanel(h4(id="pw_rs_h4_1","Check for ring count errors"),
                                                            plotOutput("pairwise_hm_small") %>% withSpinner(type = 1, size = 3, color="#2ca25f",  color.background = "#FFFFFF")),
                                                   tabPanel(h4(id="pw_rs_h4_2","lead lag results"),
                                                            plotOutput("pairwise_lead_lag_bar_plot") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF")))),
                                             box(width = 4,
                                                 div(style="text-align: right", actionButton("pw_plot_menu_hlp","", icon = icon("info"))),

                                                 div(tableOutput("pair_ser_names"), style = "font-size:24px"),
                                                 div(tableOutput("single_pair_res"), style = "font-size:24px"),
                                                 tabsetPanel(
                                                   tabPanel(h4(id="pw_rs_h4_3","Sample selection"),
                                                            selectInput("pairwise_selec_method", label = h4(id="pw_rs_h4_4","Selection options"), choices = list("Manually choose samples" = 1, "Select row from results table" = 2), selected = 1),
                                                            selectInput("pairwise_series_1", label = h4(id="pw_rs_h4_5","Manually select first series"), h4(c(""))),
                                                            selectInput("pairwise_series_2", label = h4(id="pw_rs_h4_6","Manually select second series"), h4(c(""))),
                                                            selectInput("auto_lag", label = h4(id="pw_rs_h4_7","Select lag"),choices = list("Best match" = 1, "Second best" = 2, "Third best" = 3, "Custom lag" = 4), selected = 1),
                                                            numericInput("PS_2_lag", h4(id="pw_rs_h4_8","Enter value for custom lag"), value =0)),
                                                   tabPanel(h4(id="pw_rs_h4_9","Plot options"),
                                                            checkboxInput("pair_line_stand", h4(id="pw_rs_h4_10","Normalise the data in the plot"), F),
                                                            selectInput("pairwise_colour_scale", label = h4(id="pw_rs_h4_11","Select colour scale"),choices = list("Blue-Grey-Red" = 1, "Grey-Red" = 2, "Grey-Blue" = 3, "White-Black" = 4), selected = 1),
                                                            checkboxInput("adjust_pair_lineX", h4(id="pw_rs_h4_12","adjust x axis scale line plot"), F),
                                                            numericInput("Pairwise_line_X_max", h4(id="pw_rs_h4_13","Max X axis value"), value =""),
                                                            numericInput("Pairwise_line_X_min", h4(id="pw_rs_h4_14","Min X axis value"), value = ""))
                                                 ),
                                                 downloadButton("pair_plot_download", h4(id="pw_rs_h4_15","Save the line plot")),
                                                 downloadButton("pair_small_hm_downlaod", h4(id="pw_rs_h4_16","Save the heat map")),
                                                 downloadButton("pair_bar_plot_download", h4(id="pw_rs_h4_17","Save the bar graph"))

                                             )),

                                           fluidRow(
                                             box(width=3, title = h4(id="pw_rs_h4_18","Step 1: Filter results by statistics"),
                                                 div(style="text-align: right", actionButton("pw_stat_filt_hlp","", icon = icon("info"))),
                                                 checkboxInput("filter_3_check", h4(id="pw_rs_h4_19","Filter by stats"), F),
                                                 numericInput("pair_r", h4(id="pw_rs_h4_20","R value"), value = 0.50),
                                                 numericInput("pair_sig", h4(id="pw_rs_h4_21","Significance value"), value =0.01),
                                                 numericInput("pair_overlap", h4(id="pw_rs_h4_22","Overlap"), value =50)
                                             ),
                                             box(width=3, title = h4(id="pw_rs_h4_23","Step 2: Filter results by series name"),
                                                 div(style="text-align: right", actionButton("pw_name_filt_hlp","", icon = icon("info"))),
                                                 checkboxInput("filter_1_check", h4(id="pw_rs_h4_24","Select target sample/filter table by sample"), F),
                                                 selectInput("pairwise_filter_1", label = h4(""), c("")),
                                                 checkboxInput("filter_2_check", h4(id="pw_rs_h4_25","Filter using Series 2"), F),
                                                 selectInput("pairwise_filter_2", label = h4(""), c(""))
                                             ),
                                             box(width = 3, title = h4(id="pw_rs_h4_26","Step 3: Check for Problematic Samples"),
                                                 div(style="text-align: right", actionButton("pw_prob_ck_hlp","", icon = icon("info"))),
                                                 numericInput("pair_prob_samp_wind", h4(id="pw_rs_h4_27","Set window to evaluate for problem samples (Years, must be even)"), value =20),
                                                 actionButton("prob_samp_check", h4(id="pw_rs_h4_28","Check for problematic samples")),
                                                 div(tableOutput("pairwise_prob_samples"), style = "font-size:24px")

                                             ),
                                             box(width = 3,
                                                 title = h4(id="pw_rs_h4_29","Step 4: Align samples"),
                                                 div(style="text-align: right", actionButton("pw_align_hlp","", icon = icon("info"))),
                                                 selectInput("align_all_pair", h4(id="pw_rs_h4_30","Series selection method"), choices = list("All series" = 1, "All series, excluding problem samples" = 2, "Manual sample selection" =3), selected = 1),
                                                 h4(id="pw_rs_h4_31","Manual sample selection"),
                                                 selectInput("align_ser_select", h4(id="pw_rs_h4_32","Manual sample selection"), label = c(""), multiple = T),
                                                 actionButton("Go_initiate_chrono", h4(id="pw_rs_h4_33","Align selected data"))

                                             )

                                           ),
                                           fluidRow(
                                             box(width=12,downloadButton("pairwise_res_download", h4(id="pw_rs_h4_35","Download results table")),
                                                 div(DT::dataTableOutput("pairwise_res_table"), style = "font-size:24px"))
                                           )),

                                  tabPanel(h4(id = "nav_h4_5", "Full Heat Map"), value ="heat_map",
                                           actionButton("example_undated_2", h4(id = "st_pt_h4_14", tags$b("Load example data"))),
                                          # actionButton("Go_pairwise", h4(id = "st_pt_h4_17","Run the analyses"), icon = icon("rocket")),
                                           div(tableOutput("loaded"), style = "font-size:24px" ),
                                           fluidRow(box(width=12,
                                                        div(style="text-align: left", actionButton("pw_heatmap_hlp","", icon = icon("info"))),
                                                        plotOutput("plot_sing_hm", height = "100%") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF")
                                           )),
                                           fluidRow(box(width=4,
                                                        actionButton("go2", h4(id="pw_ht_h4_1","Produce heat map")),
                                                        h4(id="pw_ht_h4_2","Select series to analyse"),
                                                        selectInput("sing_first_series", label = h4(id="pw_ht_h4_3","First series"), c("")),
                                                        selectInput("sing_second_series", label = h4(id="pw_ht_h4_4","Second series"), c("")),
                                                        h4(id="pw_ht_h4_5","Save plot"),
                                                        downloadButton('downloadsinghtmp',label=h4(id="pw_ht_h4_6","Download plot as png"))),
                                                    box(width=4, h4(id="pw_ht_h4_7","Y axis options"),
                                                        checkboxInput("adj_lag1", h4(id="pw_ht_h4_8","Adjust lag scale"), value = F),
                                                        numericInput("p_neg_lag1", h4(id="pw_ht_h4_9","Adjust negative lag (years)"), value =-20),
                                                        numericInput("p_pos_lag1", h4(id="pw_ht_h4_10","Adjust positivelag (years)"), value =20),
                                                        selectInput("pairwise_main_colour_scale", label = h4(id="pw_ht_h4_11","Select colour scale"),choices = list("Blue-Grey-Red" = 1, "Grey-Red" = 2, "Grey-Blue" = 3, "White-Black" = 4), selected = 1)
                                                        #numericInput("sing.hm.y.tick.spc", label = "Y-axis tick mark spacing", value = 10)
                                                    ),
                                                    box(width=4, h4(id="pw_ht_h4_12","x axis options"),
                                                        checkboxInput("adj_x_sing", h4(id="pw_ht_h4_13","Adjust X axis scale"), value = F),
                                                        numericInput("min_x_sing", h4(id="pw_ht_h4_14","Adjust min X axis value (years)"), value =""),
                                                        numericInput("max_x_sing", h4(id="pw_ht_h4_15","Adjust min X axis value (years)"), value ="")
                                                    )
                                           )),

                                  tabPanel(h4(id = "nav_h4_6", "Aligned data"), value = "initiatedres",
                                           fluidRow(box(width = 9,  height = 1200,
                                                        div(style="text-align: left", actionButton("al_pw_general_hlp","", icon = icon("info"))),
                                                        tabsetPanel(id = "align_data", tabPanel(h4("All aligned data"),
                                                                                                h4(id="al_dt_h4_1","Black lines = individual aligned series; red line = arithmetic mean chronology"),
                                                                                                plotOutput("initiated_chron_plot", height = "100%") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF")),
                                                                    tabPanel(h4(id="al_dt_h4_2","Sample depth plot"),
                                                                             plotOutput("sample_dist_plot") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF")),
                                                                    tabPanel(value = "prob_samp_plots", h4(id="al_dt_h4_3","Evaluate problematic samples"),
                                                                             # plotOutput("prob_sample_plot") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF"),
                                                                             plotOutput("align_prob_heatmap") %>% withSpinner(type = 1, size = 3, color="#2ca25f", color.background = "#FFFFFF"))


                                                        )),

                                                    box(width = 3,
                                                        div(style="text-align: left", actionButton("al_pw_menu_hlp","", icon = icon("info"))),
                                                        h4(id="al_dt_h4_4","Potential problem samples"),
                                                        actionButton("reevaluate", h4(id="al_dt_h4_5","Evaluate for problem samples")),
                                                        div(tableOutput("initiated_problems"), style="font-size:24px"),
                                                        numericInput("initiated_problems_bin", h4(id="al_dt_h4_6","Set window size for problem analysis (years; must be even)"), value = 20),
                                                        selectInput("align_prob_samp", label = h4(id="al_dt_h4_7","Select problem sample to evaluate"), c("")),
                                                        actionButton("aligned_prob_check", label = h4(id="al_dt_h4_8","Plot problem samples")),
                                                        tags$hr(),
                                                        h4(id="al_dt_h4_9","Plot options"),
                                                        checkboxInput("initiated_chron_plot_x_adj", h4(id="al_dt_h4_10","Adjust X axis"), F),
                                                        numericInput("initiated_chron_plot_min_X", h4(id="al_dt_h4_11","Min X value"), value =""),
                                                        numericInput("initiated_chron_plot_max_X", h4(id="al_dt_h4_12","Min X value"), value =""),
                                                        numericInput("rbar_wind_init", h4(id="al_dt_h4_13","Select window to calculate Rbar and EPS"), value = 25),
                                                        h4(id="al_dt_h4_14","window must not be greater than the length of the series"),
                                                        numericInput("init_sample_name_sz", h4(id="al_dt_h4_15","Sample ID  size"), 5)
                                                    )),
                                           fluidRow(box(width=9,
                                                        div(style="text-align: left", actionButton("al_pw_download_hlp","", icon = icon("info"))),
                                                        downloadButton("initiated.chrono.raw", h4(id="al_dt_h4_16","Save the undetrended aligned series")),
                                                        downloadButton("initiated.chrono.detrend", h4(id="al_dt_h4_17","Save the detrended aligned series")),
                                                        downloadButton("remove_initiated_series", h4(id="al_dt_h4_18","Save undated file with dated series removed")),
                                                        downloadButton("create_initiated_chron_rwl", h4(id="al_dt_h4_19","Save RWL file")),
                                                        downloadButton("initiated_two_column", h4(id="al_dt_h4_20","Save mean chronology"))#,
                                           )),
                                           fluidRow(box(width= 9,
                                                        div(style="text-align: left", actionButton("al_pw_correl_with_replacement_hlp","", icon = icon("info"))),
                                                        h4(id="al_dt_h4_21","Correlations between individual series and mean chronology with replacement"),
                                                        div(tableOutput("initiated_chron_correl_replace"), style ="font-size: 24px")
                                           )))
                      )
                  )
                ))}

shinyServer <- function(input, output, session) {

  toggle(condition = FALSE, selector = "#navbar li a[data-value=starting]")
  toggle(condition = FALSE, selector = "#navbar li a[data-value=loaded]")
  toggle(condition = FALSE, selector = "#navbar li a[data-value=detrending]")
  toggle(condition = FALSE, selector = "#navbar li a[data-value=pairwise]")
  toggle(condition = TRUE, selector = "#navbar li a[data-value=heat_map]")
  toggle(condition = FALSE, selector = "#navbar li a[data-value=initiatedres]")

  updateTabsetPanel(session, "navbar", "heat_map")

  addClass(selector = "body", class = "sidebar-collapse")

  packs<-c("data.table",
           "DataCombine",
           "DescTools",
           "doParallel",
           "dplR",
           "dplyr",
           "DT",
           "ggplot2",
           "grid",
           "gridExtra",
           "htmlwidgets",
           "readxl",
           "shiny",
           "shinyalert",
           "shinycssloaders",
           "shinydashboard",
           "shinyjs",
           "shinyWidgets",
           "stats",
           "xml2",
           "zoo",
           "zoocat")

  library(rlang)
  for (pkg in packs){
    eval(bquote(library(.(pkg))))
  }

  funcs <-list.files(path = "functions/")

  for (i in 1:length(funcs)){
    source(paste0("functions/",funcs[i]))
  }

  # Accessibility controls
  observeEvent(input$font_select, {

    # This is needed to correct for padding
    runjs(paste0('$("#form").css("font-size","', 0, 'px")'))

    change_font<-function(ft = "h1", page_name = "nav", num = 1, change = 2){

      if (change == 1){change <- 18
      } else if (change == 2){change <- 24
      } else if (change == 3){change <- 30}

      if (ft == "h1"){ft_size <- change + 10
      } else if (ft == "h2"){ft_size <- change + 8
      } else if (ft == "h3"){ft_size <- change + 6
      } else if (ft == "h4"){ft_size <- change + 4
      } else if (ft == "h5"){ft_size <- change + 2
      } else if (ft == "h6"){ft_size <- change}

      for (i in 1:num){
        runjs(paste0('$("#', page_name,'_', ft ,'_',i,'").css("font-size","', ft_size, 'px")'))
      }
    }

    # side bar fonts
    change_font(ft = "h2", page_name = "side", num = 6, change = input$font_select)

    # nav bar fonts
    change_font(ft = "h4", page_name = "nav", num = 9, change = input$font_select)

    # Starting point page fonts
    change_font(ft = "h1", page_name = "st_pt", num = 9, change = input$font_select)
    change_font(ft = "h2", page_name = "st_pt", num = 8, change = input$font_select)
    change_font(ft = "h3", page_name = "st_pt", num = 1, change = input$font_select)
    change_font(ft = "h4", page_name = "st_pt", num = 18, change = input$font_select)
    change_font(ft = "h6", page_name = "st_pt", num = 2, change = input$font_select)

    # Loaded data page fonts
    change_font(ft = "h4", page_name = "ld_dt", num = 1, change = input$font_select)

    # Detrending plot page
    change_font(ft = "h4", page_name = "dt_plt", num = 2, change = input$font_select)

    # Pairwise results page
    change_font(ft = "h4", page_name = "pw_rs", num = 35, change = input$font_select)

    # Pairwise heat map page
    change_font(ft = "h4", page_name = "pw_ht", num = 15, change = input$font_select)

    # Aligned data page
    change_font(ft = "h4", page_name = "al_dt", num = 21, change = input$font_select)
  })
  #####################################################################
  ################## Tabpanel display settings ########################
  #####################################################################

  # Code to stop RingdateR (the big red button on the starting point page).
  observe({
    if (input$close > 0) stopApp()                             # stop shiny
  })

  # jump to Pairwise page from starting point when Pairwise initiiated
  #  observeEvent(input$Go_pairwise, {
  #    updateTabsetPanel(session, "navbar",
  #                      selected = "pairwise")
  #  })

  # jump to aligned data page from pairwise results page
  observeEvent(input$Go_initiate_chrono, {
    updateTabsetPanel(session, "navbar",
                      selected = "initiatedres")
  })
  observeEvent(input$aligned_prob_check, {
    updateTabsetPanel(session, "align_data",
                      selected = "prob_samp_plots")
  })

  # jump to chronology analysis results from starting point page
  observeEvent(input$chron_analysis, {
    updateTabsetPanel(session, "navbar",
                      selected = "chrono_comp")
  })
  # jump to new chronology page  from chronology results page
  observeEvent(input$jumpTochronres, {
    updateTabsetPanel(session, "navbar",
                      selected = "newchrono")
  })

  # evaluate the size of the screen to size plots
  screen_size<-function(){
    window_height <- JS('window.innerHeight')
    window_width <- JS('window.innerWidth')
    return(class(window_width))
  }

  #####################################################################
  ################## Set up empty data.frames #########################
  #####################################################################

  # holding dataframes to store data as itis loaded
  loading               <- reactiveValues ( df_data = data.frame(NULL))
  chron_loading         <- reactiveValues ( df_data = data.frame(NULL))
  #lps_loader            <- reactiveValues ( df_data = data.frame(NULL))

  # raw chronology and undated series
  undated               <- reactiveValues ( df_data = data.frame(NULL))  # dataframe that contains the loaded data/ the data not used in the analysis
  chrono                <- reactiveValues ( df_data = data.frame(NULL))  # A dataframe containing data from a chronology

  # detrended chronology and undated series
  detrended_undated     <- reactiveValues ( df_data = data.frame(NULL))
  chron_detrended       <- reactiveValues ( df_data = data.frame(NULL))

  # combined chronology and undated series
  chron_n_undated       <- reactiveValues ( df_data = data.frame(NULL))

  # analysis results
  master_lead_lag       <- reactiveValues ( df_data = data.frame(NULL))
  pairwise_res          <- reactiveValues ( df_data = data.frame(NULL))

  # post analysis aligned chronology data
  quick_chron_alinged   <- reactiveValues ( df_data = data.frame(NULL))
  final_chron_alinged   <- reactiveValues ( df_data = data.frame(NULL))
  chron_alinged_undet   <- reactiveValues ( df_data = data.frame(NULL))

  observeEvent(input$mode_select,{

    updateCheckboxInput(session, "filter_1_check", value = FALSE)

    master_lead_lag$df_data <- data.frame(NULL)
    pairwise_res$df_data <- data.frame(NULL)

    # post analysis aligned chronology data
    quick_chron_alinged$df_data <- data.frame(NULL)
    final_chron_alinged$df_data <- data.frame(NULL)
    chron_alinged_undet$df_data <- data.frame(NULL)

  })

  ###################################################################
  ####################### Starting point page #######################
  ###################################################################

  ################ Load data #########################################

  # Function to get the file extension for loaded data
  file_detect<-function(x,n){
    substr(x, nchar(x)-n+1, nchar(x))
  }

  # Load the example data rather than using user loaded data
  observeEvent(input$example_undated_2, {
    if (ncol(undated$df_data)>1){NULL
    } else {
      loading$df_data<-read.csv("example_data/undated_example.csv")
      undated$df_data <- comb.NA(undated$df_data,loading$df_data, fill = NA)
      undated$df_data<-undated$df_data[,-1] # remove the first
      chrono$df_data <- read.csv("example_data/dated_example.csv")
    }
  })

  output$loaded<-renderTable(if (nrow(undated$df_data)>1){data.frame(DATA ="Data loaded - Now click the 'Run the Analysis' button to run the analyses.")
  } else {NULL} )

  # Load users undated data
  observeEvent(input$file1, {

    # Load undated chronology
    if (input$multi_chron==2){

      loaded_data<-ld_undated_chron(files = input$file1$datapath, series_names = input$file1$name, pair_detrend = input$pair_detrend, detrending_select = input$detrending_select, splinewindow = input$splinewindow, powerT = input$PT, shiny = TRUE)

      # make sure that the first column contains a continuous ring count for the full length of all the loaded undated chronologies.
      if (ncol(undated$df_data)<1){
        undated$df_data <- loaded_data
      } else {undated$df_data <- comb.NA(undated$df_data, loaded_data[,-1], fill = NA) }
      undated$df_data[,1]<-c(undated$df_data[1,1]:(undated$df_data[1,1] + nrow(undated$df_data) - 1))

      detrended_undated$df_data <- undated$df_data
    }

    # Load individual undated series (i.e. not undated chronologies)
    if (input$multi_chron==1){

      if (input$year_inc_select==1){col1<-"Year"
      } else {col1<-"Increment" }
      loaded_data<- load_undated(files = input$file1$datapath, series_names = input$file1$name, col1 = col1, shiny = TRUE)

      if (ncol(undated$df_data)<1){
        undated$df_data <- loaded_data
      } else {undated$df_data <- comb.NA(undated$df_data, loaded_data[,-1], fill = NA) }
      undated$df_data[,1]<-c(undated$df_data[1,1]:(undated$df_data[1,1] + nrow(undated$df_data) - 1))

    }
  })
  # Load a dated chronology for Chronology Analysis Mode
  observeEvent(input$file2, {
    chrono$df_data <- load_chron(input$file2$datapath)
  })

  # perform a quick check that the undated series are formated correctly


  # check the dated chronology data are formatted correctly
  chrono_data_check<-function(){

    the_data<-chrono$df_data

    max_date<-c()
    min_date<-c()
    a<-2
    rep_lim<-ncol(the_data)-1

    for (i in 1:rep_lim){
      sub<-the_data[,c(1,a)]
      sub<-subset(sub, complete.cases(sub))
      max_tmp<-max(sub[,1])
      min_tmp<-min(sub[,1])
      max_date<-c(max_date,max_tmp)
      min_date<-c(min_date,min_tmp)
      a<-a+1
    }

    the_data<-subset(the_data, the_data[,1]>=min(min_date) & the_data[,1]<=max(max_date))

    chron_loading$df_data <- the_data
    chrono$df_data <- the_data
    return(the_data)
  }

  # Clear the loaded data and all the results. Resets RingdateR - does not remove plots though
  observeEvent(input$Go_clear_loaded, {

    shinyjs::reset("form")
    loading$df_data <- data.frame(NULL)
    undated$df_data<-data.frame(NULL)
    detrended_undated$df_data <- data.frame(NULL)
    chrono$df_data<-data.frame(NULL)
    master_lead_lag$df_data <- data.frame(NULL)
    session$sendCustomMessage(type = "resetFileInputHandler", "file1")
    session$sendCustomMessage(type = "resetFileInputHandler", "file2")
  })

  ############### Starting Point Page Outputs ##############################
  sample_table<-function(){
    undated<-data.frame(undated = colnames(undated$df_data)[-1])
    dated <- colnames(chrono$df_data)[-1]
    combined<-comb.NA(undated, dated, fill="-")
    colnames(combined)<-c("Undated samples", "Dated samples")
    return(combined)
  }

  # Generate the list of sample IDs to show in the Step three box
  output$analysis.data.out <- renderTable(if(nrow(sample_table())<1){
    data.frame(Loaded_data = "No data loaded")  } else {sample_table()})

  # This plot generates the three line busy gif to let the user know RingdateR is loading data on the starting point page
  load_data_plot<-function(){

    #data<-undated$df_data[,ncol(undated$df_data)]
    plot1<- RingdateR_error_message(message="")
    return(plot1)
  }

  output$load_plot<-renderPlot({load_data_plot()}, height = 10)

  ###########################################################################
  ######################### Loaded data pages ###############################
  ###########################################################################

  ############## detrending and combine with chronoology ####################

  # detrend the undated series
  detrending <- function(){
    if ((ncol(undated$df_data)<=2) || (is.null(pairwise_data_check(undated$df_data)))){ NULL
    } else {
      if (input$multi_chron==2){
        detrended.data    <- undated$df_data
      } else {
        req(input$splinewindow)
        undetrended.data  <- pairwise_data_check(undated$df_data)

        if (input$pair_detrend){detrend_opt<-input$detrending_select
        } else {detrend_opt<-1}

        detrended.data    <- normalise(the.data = undetrended.data, detrend_opt, input$splinewindow)}
      detrended_undated$df_data<-detrended.data
      return(detrended.data)}
  }

  # Detrend the dated chronology and generate the arithemtic mean chronology
  chron_mean <- function(){
    if (ncol(chrono$df_data)<2){return(NULL)
    } else {
      req(input$splinewindow)
      the_data<-chrono_data_check()
      chrono$df_data<-the_data

      if (input$chron_detrend){detrend_opt<-input$detrending_select
      } else {detrend_opt<-1}
      # if detrending is selected detrend the series in the chronology
      dtnd.chron<-normalise(the.data = the_data, detrend_opt, input$splinewindow)
      chron_detrended$df_data <- dtnd.chron
      # if there is more than one series in the chronology, generate the arithmetic mean chronology
      if(ncol(dtnd.chron)>2){
        chron_mean<-rowMeans(dtnd.chron[,-1], na.rm = T)

        # if there is only one series in the chronology it is already a chronology
      } else {chron_mean<-chrono$df_data[,2]}

      chron_dat<-data.frame(dtnd.chron[,1],chron_mean)
      chron_dat<-subset(chron_dat,!is.na(chron_dat[,2]))
      return(chron_dat)
    }
  }

  # Create a data frame that contains the dated chronology and the undated series
  chron_n_series<-function(){
    if((ncol(detrended_undated$df_data)<1) || is.null(chron_mean())){return(NULL)
    } else {
      chron_dat<-chron_mean()
      de.tnd<-detrended_undated$df_data
      series_IDs<-colnames(de.tnd)

      if (ncol(de.tnd)>2){
        de.tnd.srt<- data.frame(de.tnd[,1])
        a<-2

        for (i in 1:(ncol(de.tnd)-1)){
          tmp<-de.tnd[,a]
          tmp<-subset(tmp,!is.na(tmp))
          de.tnd.srt<-comb.NA(de.tnd.srt,tmp, fill = NA)
          a<-a+1
        }
        de.tnd<-de.tnd.srt
        colnames(de.tnd) <- series_IDs
      }

      chron_len<-length(chron_dat[,1])
      series_len<-length(de.tnd[,1])
      chron_strt<-chron_dat[1,1]
      no.series<-ncol(de.tnd)

      undat.rng<-c(min(de.tnd[,1]),max(de.tnd[,1]))
      chron.rng<-c(min(chron_dat[,1]),max(chron_dat[,1]))

      de.tnd.comb<-comb.NA(chron_dat,de.tnd[,-1], fill = NA)

      if(length(de.tnd[,1])>length(chron_dat[,1])){
        limit<-length(de.tnd[,1])
      } else if (length(de.tnd[,1])<length(chron_dat[,1])) {
        limit<-length(chron_dat[,1])
      } else{limit<-length(chron_dat[,1]) }

      new.yrs<-c(min(chron.rng):(min(chron.rng)+limit-1))

      de.tnd.comb<-cbind(new.yrs,de.tnd.comb[,-1])
      colnames(de.tnd.comb)<-c("Year","Mean_chronology", series_IDs[-1])

      chron_n_undated$df_data<-de.tnd.comb
      return(de.tnd.comb)}
  }

  ##################### loaded data page outputs ###########################

  # Generate a summary table of the undated data
  undated_summary<-function(){
    the_data<-undated$df_data
    res<-load_data_tabs(the_data)
    return(res)
  }

  # display the undated summary table
  output$undated_data_table <- renderTable({if (class(undated$df_data)== c("integer")) {NULL
  } else if(ncol(undated$df_data)<1 ){
    NULL  } else {undated_summary()}})

  # Generate a summary table of the dated chronology data
  chrono_summary<-function(){
    the_data<-chrono$df_data
    res<-load_data_tabs(the_data)
    return(res)
  }

  # display the chronology summary table
  output$loaded_chronology_data_table <- renderTable({if (class(chrono$df_data)== c("integer")) {NULL
  } else if(ncol(chrono$df_data)<=2 ){
    NULL  } else {chrono_summary()}})

  detrending_data_summary<-function(){
    the_data<-detrended_undated$df_data
    if (ncol(detrended_undated$df_data)<1){NULL
    }else {
      res<-load_data_tabs(the_data)
      return(res)}
  }

  output$detrended_data_table <- renderTable({detrending_data_summary()})

  ###############################################################
  ################### Detrending plot page ######################
  ###############################################################

  #select which series to plot
  # Generates a drop down list contain the name of each series loaded as undated data
  observe({
    x <- names(undated$df_data)[-1]

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- names(undated$df_data)[-1]

    # Can also set the label and select items
    updateSelectInput(session, "first_series",
                      choices = x,
                      selected = head(x, 1)
    )
  })

  # generate the plot
  detrending.plot<-function(){
    detrending.plot.fun(undet.data = undated$df_data,  first_series = input$first_series, detrending_select = input$detrending_select, splinewindow = input$splinewindow, font_size = input$text.size, axis_line_width = input$line.width, plot_line = input$plot.line)
  }

  # Plot the detrending plot
  output$detrending.plot.out <- renderPlot({
    detrending.plot()
  }, height = 1000, res = 120)

  ####################################################################
  ######################### Pairwise page ############################
  ####################################################################

  # Run the lead lag analysis
  interseries<-eventReactive(input$Go_pairwise,{
    req(input$neg_lag)
    req(input$pos_lag)

    if (input$mode_select == 1){the_data <- detrended_undated$df_data
    } else if (input$mode_select == 2){the_data <- chron_n_undated$df_data}

    progress <- Progress$new(session, min=1, max= 100, style = "notification")
    on.exit(progress$close())

    progress$set(message = 'Calculation initiating')
    progress$set(value = 100)
    progress$set(message = 'Calculation in progress',
                 detail = 'This may take a while...')
    run_pairwise<-lead_lag_analysis(the_data = the_data, mode = input$mode_select, neg_lag = as.numeric(input$neg_lag), pos_lag = as.numeric(input$pos_lag), complete = input$total_overlap, shiny = TRUE)
    pairwise_res$df_data<-as.data.frame(run_pairwise[1])
    master_lead_lag$df_data<-as.data.frame(run_pairwise[2])[,-1]
  })

  master_res_sort<-function(){
    if (ncol(master_lead_lag$df_data)<=2){NULL
    } else {
      the_data<-master_lead_lag$df_data

      if (input$mode_select == 1){sample_1<-input$pairwise_series_1}
      if (input$mode_select == 2){sample_1<-"Mean_chronology"}

      sample_2<-input$pairwise_series_2

      if (input$pairwise_selec_method==1){
        if (sample_1==sample_2){ return(NULL)
        } else {

          samp_names<-paste0("ser_1_",sample_1, "_ser_2_",sample_2, "_")
          master_names<-c("lag", "R_Val", "P_Val", "T_val", "Overlap", "First_ring", "Last_ring")
          master_names<-paste0(samp_names,master_names)

          if (length(which(names(the_data)==master_names[1]))==0){

            samp_names<-paste0("ser_1_",sample_2, "_ser_2_",sample_1, "_")
            master_names<-c("lag", "R_Val", "P_Val", "T_val", "Overlap", "First_ring", "Last_ring")
            master_names<-paste0(samp_names,master_names)
          }

          lag <-the_data[[master_names[1]]]
          R_Val<-the_data[[master_names[2]]]
          P_Val <-the_data[[master_names[3]]]
          T_val <-the_data[[master_names[4]]]
          Overlap <-the_data[[master_names[5]]]
          First_ring	<-the_data[[master_names[6]]]
          Last_ring <-the_data[[master_names[7]]]
          selected<-data.frame(lag, R_Val, P_Val, T_val, Overlap, First_ring, Last_ring)
        }
      }
      if (input$pairwise_selec_method==2){
        if (is.null(input$pairwise_res_table_rows_selected)){
          selected<-select(the_data, contains(sample_1))
          selected<-select(selected, contains(sample_2))
        } else {
          samp_names<-paste0("ser_1_",interseries_filt()[input$pairwise_res_table_rows_selected,1], "_ser_2_",interseries_filt()[input$pairwise_res_table_rows_selected,2], "_")
          master_names<-c("lag", "R_Val", "P_Val", "T_val", "Overlap", "First_ring", "Last_ring")
          master_names<-paste0(samp_names,master_names)

          if (length(which(names(the_data)==master_names[1]))==0){
            samp_names<-paste0("ser_1_",interseries_filt()[input$pairwise_res_table_rows_selected,1], "_ser_2_",interseries_filt()[input$pairwise_res_table_rows_selected,2], "_")
            master_names<-c("lag", "R_Val", "P_Val", "T_val", "Overlap", "First_ring", "Last_ring")
            master_names<-paste0(samp_names,master_names)
          }

          lag <-the_data[[master_names[1]]]
          R_Val<-the_data[[master_names[2]]]
          P_Val <-the_data[[master_names[3]]]
          T_val <-the_data[[master_names[4]]]
          Overlap <-the_data[[master_names[5]]]
          First_ring	<-the_data[[master_names[6]]]
          Last_ring <-the_data[[master_names[7]]]
          selected<-data.frame(lag, R_Val, P_Val, T_val, Overlap, First_ring, Last_ring)

        }

      }

      colnames(selected)<-c("lag",	"R Val",	"P Val",	"T_val",	"Overlap",	"First ring",	"Last ring")

      selected<-subset(selected,(selected[,2]>0))
      ordered<-selected[order(selected[,3]),]
      return(ordered)
    }
  }


  # Select series to filter the results table by
  observe({
    if (input$mode_select== 1){x <- names(undated$df_data)[c(-1)]
    } else if (input$mode_select== 2){x <- names(chron_n_undated$df_data)[2]}

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- "no samples selected"

    # Can also set the label and select items
    updateSelectInput(session, "pairwise_filter_1",

                      choices = x,
                      selected = head(x, 1)
    )
  })
  observe({
    if (input$mode_select== 1){x <- names(undated$df_data)[c(-1
    )]
    } else if (input$mode_select== 2){x <- names(chron_n_undated$df_data)[c(-1,-2)]}

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- names(undated$df_data)[c(-1,-2)]

    # Can also set the label and select items
    updateSelectInput(session, "pairwise_filter_2",
                      choices = x,
                      selected = head(x, 2)
    )
  })

  # Filter the results dispplayed in the table
  interseries_filt<-function(){
    if(is.null(interseries())){return(NULL)
    } else {
      the.data<-pairwise_res$df_data
      if(ncol(the.data)<2){NULL
      } else {
        if(input$filter_1_check){
          tmp_1<-subset(the.data,(the.data[,1]==input$pairwise_filter_1))
          tmp_2<-subset(the.data,(the.data[,2]==input$pairwise_filter_1))
          the.data<-rbind(tmp_1,tmp_2)}
        the.data<-subset(the.data, !is.na(the.data[,6]))
        if(input$filter_2_check){
          the.data<-subset(the.data,(the.data[,2]==input$pairwise_filter_2))}
        if(input$filter_3_check){
          the.data<-subset(the.data,(the.data[,7]>=input$pair_r) & (the.data[,8]<=input$pair_sig) & (the.data[,9]>=input$pair_overlap))
        }
        the.data[,7]<-signif(the.data[,7],3)
        the.data[,8]<-signif(the.data[,8],5)
        the.data[,11]<-signif(the.data[,11],3)
        the.data[,12]<-signif(the.data[,12],5)
        the.data[,15]<-signif(the.data[,15],3)
        the.data[,16]<-signif(the.data[,16],5)
        return(the.data)}
    }
  }

  # Display the results table
  output$pairwise_res_table<-DT::renderDataTable(interseries_filt()[,-5], options = list(autoWidth = FALSE), server = T, selection = 'single')

  # Select series to plot in line and ring error plots
  observe({
    if (input$mode_select== 1){x <- names(undated$df_data)[c(-1)]
    } else if (input$mode_select== 2){x <- names(chron_n_undated$df_data)[2]}


    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- names(undated$df_data)[c(-1,-2)]

    # Can also set the label and select items
    updateSelectInput(session, "pairwise_series_1",
                      choices = x,
                      selected = head(x, 1)
    )
  })

  observe({
    if (input$mode_select== 1){x <- names(undated$df_data)[c(-1)]
    } else if (input$mode_select== 2){x <- names(chron_n_undated$df_data)[c(-1,-2)]}

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- names(undated$df_data)[c(-1,-2)]

    # Can also set the label and select items
    updateSelectInput(session, "pairwise_series_2",
                      choices = x,
                      selected = head(x, 2)
    )
  })

  # Generate the range of values for the x-axis for the line plot on the pairwise results page
  x_axis_line_func<-function(){
    if (is.null(master_res_sort())){ return(NULL)
    } else {

      if (input$mode_select == 1){the.data <-detrending()
      } else if (input$mode_select == 2){the.data <- chron_n_undated$df_data}

      cross_dates<-master_res_sort()
      lag_choice<-as.numeric(input$auto_lag)

      if (input$pairwise_selec_method==1){

        if (input$mode_select== 1){series_1<-data.frame(the.data[,1], the.data[[input$pairwise_series_1]])
        } else if (input$mode_select== 2){series_1<-data.frame(the.data[,1], the.data[,2])}

        series_1<-data.frame(the.data[,1], the.data[[input$pairwise_series_1]])
        series_2<-data.frame(the.data[,1], the.data[[input$pairwise_series_2]])}

      if(input$pairwise_selec_method==2){
        if (is.null(input$pairwise_res_table_rows_selected)){
          series_1<-data.frame(the.data[,1], the.data[[input$pairwise_series_1]])
          series_2<-data.frame(the.data[,1], the.data[[input$pairwise_series_2]])

        } else {
          series_1<-data.frame(the.data[,1], the.data[[interseries_filt()[input$pairwise_res_table_rows_selected,1]]])
          series_2<-data.frame(the.data[,1], the.data[[interseries_filt()[input$pairwise_res_table_rows_selected,2]]])
        }
      }

      series_1<-subset(series_1, (complete.cases(series_1)))
      series_2<-subset(series_2, (complete.cases(series_2)))

      if (lag_choice==4){ shift <-input$PS_2_lag
      }else {
        shift<-cross_dates[lag_choice,1]}

      series_2[,1]<-series_2[,1]+shift

      x.min<-min(c(min(series_1[,1]),min(series_2[,1])))
      x.max<-max(c(max(series_1[,1]),max(series_2[,1])))
      range<-c(x.min,x.max)
      return(range)}
  }

  # adjust the x-axis scale
  # generate pairwise line plot
  pairwise_plot_fun<- function(font_size = input$text.size, axis_line_width = input$line.width, plot_line = input$plot.line){
    if (is.null(master_res_sort())){
      plot1<- RingdateR_error_message(message="Return to starting point, load some data and click run analysis")
      return(plot1)
    } else {

      if (input$mode_select == 1){the.data <-detrending()
      } else if (input$mode_select == 2){the.data <- chron_n_undated$df_data}

      cross_dates<-master_res_sort()
      lag_choice<-as.numeric(input$auto_lag)

      if(input$pairwise_selec_method==1){
        ser_1<-which(names(the.data)==input$pairwise_series_1)
        ser_2<-which(names(the.data)==input$pairwise_series_2)
        if (ser_1<ser_2){
          series_1<-data.frame(the.data[,1], the.data[[input$pairwise_series_1]])
          series_2<-data.frame(the.data[,1], the.data[[input$pairwise_series_2]])
          series_names<-c(input$pairwise_series_1,input$pairwise_series_2)
        } else{
          series_1<-data.frame(the.data[,1], the.data[[input$pairwise_series_2]])
          series_2<-data.frame(the.data[,1], the.data[[input$pairwise_series_1]])
          series_names<-c(input$pairwise_series_2,input$pairwise_series_1)
        }

      }

      if(input$pairwise_selec_method==2){

        if (is.null(input$pairwise_res_table_rows_selected)){
          series_1<-data.frame(the.data[,1], the.data[[input$pairwise_series_1]])
          series_2<-data.frame(the.data[,1], the.data[[input$pairwise_series_2]])

        } else {
          series_1<-data.frame(the.data[,1], the.data[[interseries_filt()[input$pairwise_res_table_rows_selected,1]]])
          series_2<-data.frame(the.data[,1], the.data[[interseries_filt()[input$pairwise_res_table_rows_selected,2]]])
        }
      }

      series_1<-subset(series_1, (complete.cases(series_1)))
      series_2<-subset(series_2, (complete.cases(series_2)))

      if(input$pair_line_stand){
        series_1[,2]<- scale(series_1[,2], center = T, scale = T)
        series_2[,2]<- scale(series_2[,2], center = T, scale = T)
      }

      if (lag_choice==4){ shift <-input$PS_2_lag
      }else {
        shift<-cross_dates[lag_choice,1]}

      series_2[,1]<-series_2[,1]+shift

      x.min<-min(c(min(series_1[,1]),min(series_2[,1])))
      x.max<-max(c(max(series_1[,1]),max(series_2[,1])))

      if(input$year_inc_select==1){x.lab<-"Year"
      } else {x.lab<-"Increment number" }


      if(input$adjust_pair_lineX){

        if (!is.na(input$Pairwise_line_X_max)){
          max_val<- input$Pairwise_line_X_max
        } else {
          max_val<-x_axis_line_func()[2]
        }

        if (!is.na( input$Pairwise_line_X_min)){
          min_val<- input$Pairwise_line_X_min
        } else {min_val<-x_axis_line_func()[1] }

        series_1<-subset(series_1, ((series_1[,1]<=max_val) & (series_1[,1]>=min_val)))
        series_2<-subset(series_2, ((series_2[,1]<=max_val) & (series_2[,1]>=min_val)))
      }

      if (input$pairwise_selec_method==1){
        plot.title<-paste0(series_names[1], " (black line) and ", series_names[2], " lagged by ", shift, " years (red line)" )
      }

      if (input$pairwise_selec_method==2){
        if (is.null(input$pairwise_res_table_rows_selected)){
          plot.title<-paste0(input$pairwise_series_1, " (black line) and ", input$pairwise_series_2, " lagged by ", shift, " years (red line)" )
        }
        plot.title<-paste0(interseries_filt()[input$pairwise_res_table_rows_selected,1], " (black line) and ", interseries_filt()[input$pairwise_res_table_rows_selected,2], " lagged by ", shift, " years (red line)" )
      }

      plot1<-ggplot()+
        geom_line(data = series_1, aes(x=series_1[,1], y=series_1[,2]), na.rm=TRUE, colour="black", size = plot_line) + labs(title = plot.title) +
        geom_line(data = series_2, aes(x=series_2[,1], y=series_2[,2]), na.rm=TRUE, colour="red", size = plot_line) + R_dateR_theme(text.size = font_size + 4, line.width = axis_line_width) +
        ylab("Standardised increment width") + xlab(x.lab) +
        scale_x_continuous(breaks = x.scale.bar(round(min(x_axis_line_func()), -1), round(max(x_axis_line_func()), -1)))


      return(plot1)}
  }

  # output pairwise line plot
  output$pairwise_line_plot <- renderPlot({
    pairwise_plot_fun()
  }, height = 450)

  observe({
    if (input$adjust_pair_lineX){x <- x_axis_line_func()[1]
    } else {x<-0}

    # Can also set the label and select items
    updateNumericInput(session, "Pairwise_line_X_min",
                       value = x
    )
  })

  observe({
    if (input$adjust_pair_lineX){x <- x_axis_line_func()[2]
    } else {x<-1}

    # Can also set the label and select items
    updateNumericInput(session, "Pairwise_line_X_max",
                       value = x
    )
  })

  # generates the series neames text above the summary table on the pairwise results page
  pair_ser_names<-function(){
    if (is.null(master_res_sort())){ return(NULL)
    } else {
      if(input$pairwise_selec_method==1){
        data<-data.frame(paste0(input$pairwise_series_1," vs ", input$pairwise_series_2))

      }

      if(input$pairwise_selec_method==2){
        if (is.null(input$pairwise_res_table_rows_selected)){
          data<-data.frame(paste0(input$pairwise_series_1," vs ", input$pairwise_series_2))
        } else {
          data<-data.frame(paste0(interseries_filt()[input$pairwise_res_table_rows_selected,1]," vs ", interseries_filt()[input$pairwise_res_table_rows_selected,2]))
        }
      }

      colnames(data)<-c("Analysed series")
      return(data)}
  }


  output$pair_ser_names<-renderTable({pair_ser_names()})

  small_res_table<-function(){
    if (is.null(master_res_sort())){ return(NULL)
    } else {
      res<-master_res_sort()[1:3,]
      Ranking<-c("Best match (red bar)","Second best (blue bar)","Third best (green bar)")
      res<-data.frame(cbind(Ranking,res))
      return(res)}
  }

  output$single_pair_res<-renderTable({small_res_table()})

  # The function to run the running lead-lag analysis
  correl_heat_map<-function(the.data = the.data, s1 = 2, s2 = 2, neg_lag = -10, pos_lag = 10, N_limit = 21, win = 21, complete=F){

    new<-the.data

    a<-new[s1]
    b<-new[s2]

    new<-data.frame(new[,1],a,b, stringsAsFactors = T)
    colnames(new)<-c("years","A","B")
    shell_ID<-colnames(the.data)

    N_limit<-win
    win<-win
    ###########################################################

    run_cor_res<-data.frame()

    #extract the data for the analysis
    years<-new[,1]
    shell_a<-new[,2]
    shell_b<-new[,3]
    run.cor.dat<-data.frame(years,shell_a,shell_b)

    ser_a_len<-length(subset(shell_a, (!is.na(shell_a))))
    ser_b_len<-length(subset(shell_b, (!is.na(shell_b))))

    #pos_lag_lim<-length(subset(shell_a, (!is.na(shell_a))))-N_limit
    #neg_lag_lim<--length(subset(shell_b, (!is.na(shell_b))))+N_limit-100
    pos_lag_lim<- max(c(ser_a_len,ser_b_len))
    neg_lag_lim<- -max(c(ser_a_len,ser_b_len))

    if(complete){pos_lag<-pos_lag_lim   # tells the analysis to run over the maximum allowable lead-lag
    neg_lag<-neg_lag_lim}

    if (pos_lag>pos_lag_lim){max_pos_lag<-pos_lag_lim
    } else {max_pos_lag<-pos_lag}

    if (neg_lag<neg_lag_lim){max_neg_lag<-neg_lag_lim
    } else {max_neg_lag<-neg_lag}

    # set up the data for the analysis

    lag<-max_neg_lag

    repeat {
      if(lag<=-1){
        NA_ser<-rep(NA,abs(lag))
        yr_mod<-c(NA_ser,years)
        mod_ser_1<-c(NA_ser,shell_a)
        mod_ser_2<-c(shell_b,NA_ser)
        analysis.data<-comb.NA(yr_mod,mod_ser_1,mod_ser_2, fill = NA)
      } else if (lag==0){
        yr_mod<-years
        mod_ser_1<-shell_a
        mod_ser_2<-shell_b
        analysis.data<-comb.NA(yr_mod,mod_ser_1,mod_ser_2, fill = NA)
      } else if(lag>=1){
        NA_ser<-rep(NA,lag)
        yr_mod<-c(years,NA_ser)
        mod_ser_1<-c(shell_a,NA_ser)
        mod_ser_2<-c(NA_ser,shell_b)
        analysis.data<-comb.NA(yr_mod,mod_ser_1,mod_ser_2, fill = NA)
      }

      len_test<-subset(analysis.data, complete.cases(analysis.data))
      analysis.data<-subset(analysis.data, complete.cases(analysis.data))

      if(nrow(analysis.data)<=win){NULL

      } else {
        cor_test<-rollcor(analysis.data[,2],analysis.data[,3], width = win, show =F)
        cor_year<-rollmean(analysis.data[,1], k = win)
        lag_ser<- rep(lag,length(cor_year))

        run_cor_tmp<-comb.NA(cor_year, lag_ser, cor_test, fill = NA)
        run_cor_tmp<-subset(run_cor_tmp, complete.cases(run_cor_tmp))
        colnames(run_cor_tmp)<-c("year", "lag", "R val")

        run_cor_res<-rbind(run_cor_res,run_cor_tmp)
        colnames(run_cor_res)<-c("year", "lag", "R val")

        mod_ser_1<-NULL
        mod_ser_2<-NULL
      }
      if (lag>=max_pos_lag){break}
      lag<-lag+1


    }
    # run_cor_res<-subset(run_cor_res, complete.cases(run_cor_res))
    if(nrow(run_cor_res)<5){run_cor_res<-NULL}
    return(run_cor_res)

  }


  # Running lead lag analysis over +/-10 year window
  pairwise_small_hm_fun<-function(){
    if (is.null(master_res_sort())){ return(NULL)
    } else {
      win<-input$cor_win
      even_odd<- win %% 2 == 0 # check that the correlation window is odd.
      if(even_odd) {win<-as.numeric(win)+1 # If it is even add 1 to make it odd.
      } else {win<-win}

      if (input$mode_select == 1){the.data <-detrending()
      } else if (input$mode_select == 2){the.data <- chron_n_undated$df_data}

      cross_dates<-master_res_sort()
      lag_choice<-as.numeric(input$auto_lag)
      if (lag_choice==4){ shift <-input$PS_2_lag
      }else {
        shift<-cross_dates[lag_choice,1]

      }
      series_1<-input$pairwise_series_1
      series_2<-input$pairwise_series_2

      if (input$pairwise_selec_method==1){
        ser_1<-which(names(the.data)==input$pairwise_series_1)
        ser_2<-which(names(the.data)==input$pairwise_series_2)
        if (ser_2<ser_1){
          series_1<-input$pairwise_series_2
          series_2<-input$pairwise_series_1
        } else{
          series_1<-input$pairwise_series_1
          series_2<-input$pairwise_series_2
        }
      }


      if(input$pairwise_selec_method==2){
        if (is.null(input$pairwise_res_table_rows_selected)){
          analysis.data<-data.frame(the.data[,1], the.data[[series_1]],the.data[[series_2]])

        } else {
          analysis.data<-data.frame(the.data[,1], the.data[[interseries_filt()[input$pairwise_res_table_rows_selected,1]]],the.data[[interseries_filt()[input$pairwise_res_table_rows_selected,2]]])
        }
      }
      if(input$pairwise_selec_method==1){

        analysis.data<-data.frame(the.data[,1], the.data[[series_1]],the.data[[series_2]])
      }

      run_cor_res<-correl_heat_map(the.data = analysis.data, s1=2, s2=3, neg_lag = -10+shift, pos_lag = 10+shift, win, win, complete = F)

      return(run_cor_res)
      run_cor_res<-data.frame()}

  }


  # Plot running lead_lag analysis
  plot_pairwise_small_hm<- function(font_size = input$text.size, axis_line_width = input$line.width, plot_line = input$plot.line){
    if (is.null(master_res_sort())){
      plot1<- RingdateR_error_message(message="Return to starting point, load some data and click run analysis")
      return(plot1)
    }  else if (is.null(pairwise_small_hm_fun())){
      plot1<- RingdateR_error_message(message="Insufficient overlap to perform running correlation analysis")
      return(plot1)
    }  else {

      output_correls<-pairwise_small_hm_fun()
      plot.data<-output_correls
      new<-detrending()

      if(input$pairwise_selec_method==1){
        s1<-input$pairwise_series_1
        s2<-input$pairwise_series_2
      }

      if(input$pairwise_selec_method==2){
        if (is.null(input$pairwise_res_table_rows_selected)){
          s1<-input$pairwise_series_1
          s2<-input$pairwise_series_2

        } else {

          s1<-interseries_filt()[input$pairwise_res_table_rows_selected,1]
          s2<-interseries_filt()[input$pairwise_res_table_rows_selected,2]
        }
      }

      series.names<-colnames(new)
      #x.ticks<-input$sing.hm.x.tick.spc
      #y.ticks<-input$sing.hm.y.tick.spc
      plot.title<- paste0(s1, " vs ", s2)
      y.lab=paste0("lag (years from ", s1, ")")

      y.data<-plot.data[,2]

      if(input$year_inc_select==1){x.lab<-"Year"
      } else {x.lab<-"Increment number" }

      col_scale <- col_pal(input$pairwise_colour_scale)


      # Plot a heat map of the correlations
      plot2<-ggplot(plot.data, aes(x=plot.data[,1], y=plot.data[,2]), na.rm=TRUE) + geom_raster(aes(fill = plot.data[,3])) +
        R_dateR_theme(text.size = font_size + 4, line.width = axis_line_width) +
        scale_fill_gradientn(colours = col_scale, limits = c(-1,1)) +labs(fill = "Correl. (R)", x = x.lab, y= y.lab)  +
        scale_y_continuous(breaks = seq(min(y.data), max(y.data), by = 2)) +
        scale_x_continuous(breaks = x.scale.bar(round(min(plot.data[,1]), -1), round(max(plot.data[,1]), -1)))

      return(plot2)}
  }

  # output the running lead lag analysis
  output$pairwise_hm_small <- renderPlot({plot_pairwise_small_hm()}, height = 500)

  pairwise_bar_chart_fun<-function(font_size = input$text.size, axis_line_width = input$line.width, plot_line = input$plot.line){
    the.data<-detrended_undated$df_data
    years<-(the.data[,1])
    # the.data<-data.frame(years, the.data[[input$pairwise_series_1]],the.data[[input$pairwise_series_2]])

    test<-master_res_sort()

    test<-subset(test,(test[,2]>0))
    ordered<-test[order(test[,3]),]
    best<-ordered[1,]
    second<-ordered[2,]
    third<-ordered[3,]

    return(ggplot()+
             geom_bar(data=test, aes(x=test[,1], weight= (test[,4])), fill= "black", na.rm=T) +
             R_dateR_theme(text.size = font_size, line.width = axis_line_width) +ylab("T_val") + xlab("Lag (Year)") +
             geom_bar(data=best, aes(x=best[,1], weight= (best[,4])), fill= "red", na.rm=T) +
             geom_bar(data=second, aes(x=second[,1], weight= (second[,4])), fill= "blue", na.rm=T) +
             geom_bar(data=third, aes(x=third[,1], weight= (third[,4])), fill= "green", na.rm=T) +
             scale_x_continuous(breaks = x.scale.bar(round(min(test[,1]), -1), round(max(test[,1]), -1)))
    )
  }


  output$pairwise_lead_lag_bar_plot<-renderPlot({pairwise_bar_chart_fun()}, height = 500)

  # Aligns the data in the large results tbale.
  quick_align<-function(){
    if (input$filter_1_check==FALSE){NULL
    } else {
      if (input$mode_select == 1){the_data <- detrended_undated$df_data
      } else if (input$mode_select == 2){the_data <- chron_n_undated$df_data}
      if (is.null(interseries_filt())){NULL
      } else {
        cross_dates<-interseries_filt()
        cross_dates<-subset(cross_dates, (cross_dates[,7]>=input$pair_r) & (cross_dates[,8]<=input$pair_sig) & (cross_dates[,9]>=input$pair_overlap))

        aligned_data <- align_series(the_data = the_data, cross_dates = cross_dates, sel_target = input$pairwise_filter_1)

        if(input$mode_select == 2){quick_chron_alinged$df_data<-align_to_chron(the.data = aligned_data, chrono = chron_detrended$df_data)}

        return(aligned_data)}
    }

  }

  # replace the arithemtic mean chronology with the full detrended chronology data

  observe({if(is.null(detrending())){ NULL
  } else {

    if (input$mode_select == 1){x <-c(colnames(quick_align()[-1]))
    } else if (input$mode_select == 2){x <- c(colnames(quick_chron_alinged$df_data)[-1])}

    # Can use character(0) to remove all choices
    if (is.null(quick_align()))
      x <- c("No series")

    # Can also set the label and select items
    updateSelectInput(session, "align_ser_select",
                      choices = x,
                      selected = head(x, 1)
    )
  }
  })

  ####################################################################
  ##################### Full heat map page #######################
  ####################################################################

  # select the series to run in the analysis
  observe({
    if (input$mode_select == 1){x <-colnames(detrended_undated$df_data)[-1]
    } else if (input$mode_select == 2){x <-colnames(chron_n_undated$df_data)[-1]}

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- names(undated$df_data)[c(-1,-2)]

    # Can also set the label and select items
    updateSelectInput(session, "sing_first_series",
                      label = paste("Select input label", length(x)),
                      choices = x,
                      selected = head(x, 1)
    )
  })
  observe({
    if (input$mode_select == 1){x <-colnames(detrended_undated$df_data)[-1]
    } else if (input$mode_select == 2){x <-colnames(chron_n_undated$df_data)[-1]}

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- names(undated$df_data)[c(-1,-2)]

    # Can also set the label and select items
    updateSelectInput(session, "sing_second_series",
                      label = paste("Select input label", length(x)),
                      choices = x,
                      selected = head(x, 2)
    )
  })

  # Generate the Full pairwise heat map
  single_heat_map_analysis<-eventReactive(input$go2, {
    if(nrow(detrended_undated$df_data)<1 || nrow(chron_n_undated$df_data)<2){return(NULL)
    } else {
      if (input$mode_select == 1){the_data <- detrended_undated$df_data
      } else if (input$mode_select == 2){the_data <- chron_n_undated$df_data}

      running_lead_lag(the_data = the_data, win= input$cor_win, s1 = input$sing_first_series, s2 = input$sing_second_series, neg_lag = input$neg_lag, pos_lag = input$pos_lag, complete=input$total_overlap)}
  })

  # adjust the x-axis scale
  observe({
    if(is.null(single_heat_map_analysis())){x <- 0
    } else {
      x <- min(single_heat_map_analysis()[,1])}
    # Can also set the label and select items
    updateNumericInput(session, "min_x_sing",
                       value = x
    )
  })
  observe({
    if(is.null(single_heat_map_analysis())){x <- 1
    } else {
      x <- max(single_heat_map_analysis()[,1])}

    # Can also set the label and select items
    updateNumericInput(session, "max_x_sing",
                       value = x
    )
  })

  plot.title.pair.hm<-eventReactive(input$go2, {
    s1<-input$sing_first_series
    s2<-input$sing_second_series
    plot.title<- paste0(s1, " vs ", s2)
    return(plot.title)
  })

  y.lab.tltle<-eventReactive(input$go2, {
    s1<-input$sing_first_series
    y.lab<-paste0("lag (years from ", s1, ")")
    return(y.lab)
  })

  #plot pairwise heatmap
  plotting_sing_hm<- function(font_size = input$text.size, axis_line_width = input$line.width, plot_line = input$plot.line){
    if(is.null(single_heat_map_analysis())){return(RingdateR_error_message("Insufficient overlap to perform running correlation analysis"))
    } else {
      output_correls<-single_heat_map_analysis()
      plot.data<-output_correls


      if(input$adj_lag1){
        validate(need(input$p_neg_lag1, message = "Enter a negative lag value"))
        validate(need(input$p_pos_lag1, message = "Enter a positive lag value"))
        plot.data<-subset(plot.data,((plot.data[,2]>=input$p_neg_lag1)) & (plot.data[,2]<=input$p_pos_lag1))
      } else {plot.data<-plot.data}

      if(input$adj_x_sing){plot.data<-subset(plot.data,((plot.data[,1]>=input$min_x_sing)) & (plot.data[,1]<=input$max_x_sing))
      } else {plot.data<-plot.data}

      new<-detrended_undated$df_data
      s1<-input$sing_first_series
      s2<-input$sing_second_series
      series.names<-colnames(new)
      x.ticks<-input$sing.hm.x.tick.spc
      y.ticks<-input$sing.hm.y.tick.spc
      plot.title<- plot.title.pair.hm()
      y.lab=y.lab.tltle()

      if(input$year_inc_select==1){x.lab<-"Year"
      } else {x.lab<-"Increment number" }

      col_scale <- col_pal(input$pairwise_main_colour_scale)

      # Plot a heat map of the correlations
      if (input$adj_lag1 & (input$p_neg_lag1>=input$p_pos_lag1)){plot2<- RingdateR_error_message("Negative lag must be lower than positive lag")

      } else if (input$adj_x_sing &(input$min_x_sing>=input$max_x_sing)){plot2<- RingdateR_error_message("Min X-axis value must be lower than max x-axis value")

      } else {

        plot2<-ggplot(plot.data, aes(x=plot.data[,1], y=plot.data[,2]), na.rm=TRUE) + geom_raster(aes(fill = plot.data[,3])) + R_dateR_theme(text.size = font_size, line.width = axis_line_width) +
          scale_fill_gradientn(colours = col_scale, limits = c(-1,1)) +labs(fill = "Correl. (R)", x = x.lab, y= y.lab, title=plot.title) +
          scale_x_continuous(breaks = x.scale.bar(round(min(plot.data[,1]),-1), round(max(plot.data[,1]),-1))) +
          scale_y_continuous(breaks = y.scale.bar(min(plot.data[,2]),max(plot.data[,2])))
      }

      return(plot2)}
  }

  #output pairwise heat map
  output$plot_sing_hm <- renderPlot({
    plotting_sing_hm()}, height = 1000)


  ##################### Aligned data page ####################

  # Produce the aligned data from the selected undated series
  initiate_chrono<-eventReactive(input$Go_initiate_chrono,{
    if (input$filter_1_check==FALSE){NULL
    } else {

      if (input$mode_select == 1){the_data <- undated$df_data
      } else if (input$mode_select == 2){the_data <- chron_n_undated$df_data}

      cross_dates<-interseries_filt()
      cross_dates<-subset(cross_dates, (cross_dates[,7]>=input$pair_r) & (cross_dates[,8]<=input$pair_sig) & (cross_dates[,9]>=input$pair_overlap))

      if (nrow(cross_dates)<1){return(NULL)
      } else {

        new.chrono <- align_series(the_data = the_data, cross_dates = cross_dates, sel_target = input$pairwise_filter_1)

        if(input$mode_select == 2){new.chrono<-align_to_chron(the.data = new.chrono, chrono = chron_detrended$df_data)}

        if(input$align_all_pair==2){
          if ( ncol(pairwise_prob_check())<2){
            NULL
          } else {
            series.id<-as.vector(pairwise_prob_check()[,1])

            a<-1
            for (i in 1:length(series.id)){

              new.chrono<- new.chrono[ , -which(names(new.chrono) %in% paste0(parse(text=series.id[i])))]
              a<-a+1
            }
          }
        } else if (input$align_all_pair == 3){
          select_ser<-input$align_ser_select

          years<-new.chrono[,1]
          selected_data<-data.frame(years)

          for (i in 1:length(select_ser)){
            tmp<- new.chrono[ , which(names(new.chrono) %in% paste0(parse(text=select_ser[i])))]
            selected_data<-cbind(selected_data,tmp)
          }

          colnames(selected_data)<-c("Year", select_ser)

          new.chrono<- selected_data
        }

        max_date<-c()
        min_date<-c()
        a<-2
        rep_lim<-ncol(new.chrono)-1

        for (i in 1:rep_lim){
          sub<-new.chrono[,c(1,a)]
          sub<-subset(sub, complete.cases(sub))
          max_tmp<-max(sub[,1])
          min_tmp<-min(sub[,1])
          max_date<-c(max_date,max_tmp)
          min_date<-c(min_date,min_tmp)
          a<-a+1
        }

        new.chrono<-subset(new.chrono, new.chrono[,1]>=min(min_date) & new.chrono[,1]<=max(max_date))

        if (ncol(new.chrono)<3){
          shinyalert("Warning!", "You need to select at least two samples to align the data", type = "error")
        }

        chron_alinged_undet$df_data<-new.chrono
        return(new.chrono) }
    }
  })

  detrended_initiated_chrono<-function(){
    if (is.null(initiate_chrono())){
      NULL
    } else {
      req(input$splinewindow)
      new.chrono<-initiate_chrono()
      if (input$chron_detrend){detrend_opt<-input$detrending_select
      } else {detrend_opt<-1}
      new.chrono<-normalise(the.data = new.chrono, detrend_opt, input$splinewindow)
      final_chron_alinged$df_data<-new.chrono
      return(new.chrono)}
  }

  # performs the problem check on the Pairwise Results page
  pairwise_prob_check<-eventReactive(input$prob_samp_check,{

    if (input$mode_select == 1){new.chrono<-quick_align()
    } else if (input$mode_select == 2){new.chrono <- quick_chron_alinged$df_data}

    prob_check(new.chrono, input$pair_prob_samp_wind)

  })

  output$pairwise_prob_samples<-renderTable({pairwise_prob_check()})

  observe({
    if (is.null(plot_dplr_check())){x <- c("No Series")

    } else  if (ncol(plot_dplr_check())<2){ x <- c("No Series")

    } else if  (ncol(plot_dplr_check())>1){  x <- plot_dplr_check()[,1]

    }

    # Can also set the label and select items
    updateSelectInput(session, "align_prob_samp",

                      choices = x,
                      selected = head(x, 1)
    )
  })

  Sample_dist_fun<-function(){

    the_data<-initiate_chrono()
    plot_data<-dated_line_plot(the_data)

    plot_1<-ggplot()+
      geom_line(data = plot_data, aes(x=plot_data[,3], y = plot_data[,2], group = plot_data[,1]), size = input$plot.line, colour = "black") +
      geom_point(data = plot_data, aes(x=plot_data[,3], y = plot_data[,2], group = plot_data[,1]), size = input$plot.line, colour = "black") +
      geom_text(data = plot_data, aes(x=max(plot_data[,3])+20, y = plot_data[,2], group = plot_data[,1], label = plot_data[,1]), size = input$init_sample_name_sz) +
      R_dateR_theme(text.size = input$text.size, line.width = input$line.width,l=20) + xlab("Year") + ylab("Number of samples") +
      scale_x_continuous(breaks = x.scale.bar(round(min(plot_data[,3]), -1), round(max(plot_data[,3]), -1)))

    if (input$reevaluate>=1){
      if (ncol(plot_dplr_check())>1){
        series.id<-as.vector(plot_dplr_check()[,1])
        prob_samps<-data.frame(NULL)
        a<-1

        for (i in 1:length(series.id)){

          tmp<- plot_data[plot_data[,1] %like% series.id[i],]
          prob_samps<-rbind(prob_samps,tmp)
          a<-a+1
        }
        plot_1<-plot_1 + geom_line(data = prob_samps, aes(x=prob_samps[,3], y = prob_samps[,2], group = prob_samps[,1]), size = input$plot.line, colour = "red") +
          geom_point(data = prob_samps, aes(x=prob_samps[,3], y = prob_samps[,2], group = prob_samps[,1]), colour = "red")

      }
    }

    return(plot_1)
  }

  output$sample_dist_plot<-renderPlot({Sample_dist_fun()}, height = 1000)

  observe({
    if(is.null(initiate_chrono())) {x <- 0
    } else {
      x <-  as.numeric(min(initiate_chrono()[,1]))

    }

    # Can also set the label and select items
    updateNumericInput(session, "initiated_chron_plot_min_X",
                       value = x
    )
  })

  observe({
    if(is.null(initiate_chrono())) {x <- 1
    } else {
      x <- as.numeric(max(initiate_chrono()[,1]))
    }

    # Can also set the label and select items
    updateNumericInput(session, "initiated_chron_plot_max_X",
                       value = x
    )
  })

  # performs the secondary evaluation for problematic samples (on the aligned data page)
  plot_dplr_check<-eventReactive(input$reevaluate, {
    if (is.null(initiate_chrono())){
      NULL
    } else {

      prob_check(final_chron_alinged$df_data, input$initiated_problems_bin)
    }
  })

  output$initiated_problems<-renderTable({plot_dplr_check()})

  check_no_probs<-function(){
    no_probs<-length(plot_dplr_check()[,1])
    new.chrono.ser<-ncol(final_chron_alinged$df_data)
    return(new.chrono.ser-no_probs)
  }

  #eventReactive(input$aligned_prob_check,
  prob_samp_line_plot<- eventReactive(input$aligned_prob_check, {

    if (is.null(plot_dplr_check())){ NULL

    } else if (check_no_probs()<=3) {
      return (RingdateR_error_message(message = "Too many problem samples"))
    }  else {

      prob_sample<-final_chron_alinged$df_data[input$align_prob_samp]
      prob_sample_dates<-final_chron_alinged$df_data[,1]
      prob_sample<-data.frame(prob_sample_dates,prob_sample)
      prob_sample<-subset(prob_sample, complete.cases(prob_sample))

      new.chrono<-final_chron_alinged$df_data

      if ( ncol(plot_dplr_check())>1){

        series.id<-as.vector(plot_dplr_check()[,1])

        a<-1
        for (i in 1:length(series.id)){

          new.chrono<- new.chrono[ , -which(names(new.chrono) %in% paste0(parse(text=series.id[i])))]
          a<-a+1
        }
      }

      max_date<-c()
      min_date<-c()
      a<-2
      rep_lim<-ncol(new.chrono)-1

      for (i in 1:rep_lim){
        sub<-new.chrono[,c(1,a)]
        sub<-subset(sub, complete.cases(sub))
        max_tmp<-max(sub[,1])
        min_tmp<-min(sub[,1])
        max_date<-c(max_date,max_tmp)
        min_date<-c(min_date,min_tmp)
        a<-a+1
      }

      new.chrono<-subset(new.chrono, new.chrono[,1]>=min(min_date) & new.chrono[,1]<=max(max_date))

      chron_values<-rowMeans(new.chrono[,-1], na.rm = T)
      new.chrono<-data.frame(new.chrono[,1],chron_values)

      min_x_val<-c(min(new.chrono[,1], prob_sample[,1]))
      max_x_val<-c(max(new.chrono[,1], prob_sample[,1]))

      plot1<-ggplot()+
        geom_line(data=new.chrono, aes(x=new.chrono[,1], y = new.chrono[,2]), color="red", size =  input$plot.line, na.rm=TRUE ) +
        geom_line(data=prob_sample, aes(x=prob_sample[,1], y = prob_sample[,2]), color="black", size = input$plot.line, na.rm=TRUE) +
        R_dateR_theme(text.size = input$text.size + 4,line.width = input$line.width,l = 20) +
        scale_x_continuous(breaks = x.scale.bar(round(min(min_x_val),-1),round(max(max_x_val),-1)), limits = c(input$initiated_chron_plot_min_X,input$initiated_chron_plot_max_X)) +
        xlab("Year") + ylab("Standardised growth index") + labs(title = paste0("Mean chronology (red line), ", input$align_prob_samp, " (black line)"))
    }
    return(plot1)

  })

  # generates the problem sample heat map pon the aligned data page
  align_problem_heatmp_fun<-eventReactive(input$aligned_prob_check, {

    if (is.null(plot_dplr_check())){ NULL
    } else if (check_no_probs()<=3) {
      return (NULL)
    }  else {
      win<-input$cor_win
      even_odd<- win %% 2 == 0 # check that the correlation window is odd.
      if(even_odd) {win<-as.numeric(win)+1 # If it is even add 1 to make it odd.
      } else {win<-win}

      prob_sample<-final_chron_alinged$df_data[input$align_prob_samp]
      prob_sample_dates<-final_chron_alinged$df_data[,1]
      prob_sample<-data.frame(prob_sample_dates,prob_sample)
      prob_sample<-subset(prob_sample, complete.cases(prob_sample))

      new.chrono<-final_chron_alinged$df_data

      if ( ncol(plot_dplr_check())>1){

        series.id<-as.vector(plot_dplr_check()[,1])

        a<-1
        for (i in 1:length(series.id)){

          new.chrono<- new.chrono[ , -which(names(new.chrono) %in% paste0(parse(text=series.id[i])))]
          a<-a+1
        }
      }

      chron_values<-rowMeans(new.chrono[,-1], na.rm = T)
      new.chrono<-data.frame(new.chrono[,1],chron_values)

      min_chron<-min(new.chrono[,1])
      min_prob_sample<-min(prob_sample[,1])
      max_chron<-max(new.chrono[,1])
      max_prob_sample<-max(prob_sample[,1])

      early<-min(c(min_chron,min_prob_sample))
      late<-max(c(max_chron,max_prob_sample))
      new_dates<-c(early:late)
      the_data<-data.frame(new_dates)

      if (min_chron==min(new_dates)){new.chrono<-new.chrono[,2]
      } else if (min_chron>min(new_dates)){
        NA_ser<-rep(NA, abs(min_chron-min(new_dates)))
        new.chrono<-c(NA_ser,new.chrono[,2])
      }

      if (min_prob_sample>min(new_dates)){
        NA_ser<-rep(NA, abs(min_prob_sample-min(new_dates)))
        prob_sample<-c(NA_ser,prob_sample[,2])
      } else if (min_prob_sample==min(new_dates)){prob_sample<-prob_sample[,2]}

      the_data<-comb.NA(the_data, new.chrono, prob_sample, fill = NA)
      colnames(the_data)<-c("Year", "Mean chron", input$align_prob_samp)

      run_cor_res<-correl_heat_map(the.data = the_data, s1=2, s2=3, neg_lag = -10, pos_lag = 10, win, win, complete = F)

      return(run_cor_res)
      run_cor_res<-data.frame()}

  })

  plot_prob_heatmap_small_fun<- eventReactive(input$aligned_prob_check, {
    if (is.null(detrending())){
      plot1<- RingdateR_error_message(message="Return to starting point, load some data and click run analysis")
      return(plot1)
    }  else if (check_no_probs()<=3) {
      return (RingdateR_error_message(message = "Too many problem samples"))
    } else if (is.null(align_problem_heatmp_fun())){
      plot1<- RingdateR_error_message(message="Insufficient overlap to perform running correlation analysis")
      return(plot1)
    }  else {

      output_correls<-align_problem_heatmp_fun()
      plot.data<-output_correls
      new<-detrending()
      s1<-input$align_prob_samp
      series.names<-colnames(new)

      plot.title<- paste0("Arithemtic mean of aligned series vs ", s1)
      y.lab=paste0("lag (years from arithemtic mean chronology)")

      y.data<-plot.data[,2]

      if(input$year_inc_select==1){x.lab<-"Year"
      } else {x.lab<-"Increment number" }

      col_scale <- col_pal(input$pairwise_colour_scale)

      # Plot a heat map of the correlations
      plot2<-ggplot(plot.data, aes(x=plot.data[,1], y=plot.data[,2]), na.rm=TRUE) + geom_raster(aes(fill = plot.data[,3])) +
        R_dateR_theme(text.size = input$text.size + 4, line.width = input$line.width) +
        scale_fill_gradientn(colours = col_scale, limits = c(-1,1)) +labs(fill = "Correl. (R)", x = x.lab, y= y.lab)  +
        scale_y_continuous(breaks = seq(min(y.data), max(y.data), by = 2)) +
        scale_x_continuous(breaks = x.scale.bar(round(min(plot.data[,1]),-1),round(max(plot.data[,1]),-1)))

      return(plot2)}
  })

  final_prob_plot<-function(){
    plot1 <- prob_samp_line_plot()
    plot2<- plot_prob_heatmap_small_fun()

    g1 <- ggplotGrob(plot1)
    g2<-  ggplotGrob(plot2)

    g<-rbind(g1, g2, size = "first")
    both <-  grid.draw(g)

  }

  output$align_prob_heatmap <- renderPlot({final_prob_plot()}, height=1000)

  plot_initiated_chron<-function(){
    if (is.null(initiate_chrono())){
      plot1<- RingdateR_error_message(message="No aligned data to plot")
      return(plot1)
    } else {

      new.chrono<-detrended_initiated_chrono()

      new_chron_mean<-rowMeans(new.chrono[,-1], na.rm = T)
      chron_dat<-data.frame(new.chrono[,1],new_chron_mean)

      if((input$rbar_wind_init*1.5>nrow(new.chrono)) | (input$rbar_wind_init<=5))  {N.plot.dat<-NULL
      } else {N.plot.dat<-R_bar_EPS(the.data = new.chrono, window = input$rbar_wind_init)}

      a<-1
      b<-2
      count<-1
      new<-data.frame()

      while(b<=ncol(new.chrono)){
        tmp<-data.frame(new.chrono[,a],new.chrono[,b])
        tmp<-subset(tmp, (!is.na(tmp[,1]) & !is.na(tmp[,2])))
        group<-as.character(rep(count,length(tmp[,1])))
        tmp<-cbind(tmp,group)
        colnames(tmp)<-c("col_1","col_2","group")
        new<-rbind(new,tmp)
        b<-b+1
        count<-count+1
      }

      if (input$initiated_chron_plot_x_adj){
        new<-subset(new,((new[,1]>=as.numeric(input$initiated_chron_plot_min_X)) & new[,1]<=as.numeric(input$initiated_chron_plot_max_X)))
        chron_dat<-subset(chron_dat,((chron_dat[,1]>=as.numeric(input$initiated_chron_plot_min_X)) & chron_dat[,1]<=as.numeric(input$initiated_chron_plot_max_X)))
      }

      if(input$year_inc_select==1){x.lab<-"Year"
      } else {x.lab<-"Increment number" }

      plot1<-  ggplot()+
        geom_line(data = new, aes(x = new[,1], y = new[,2], group = new[,3]), size = input$plot.line, alpha = 0.5, na.rm=T) +
        R_dateR_theme(text.size = input$text.size, line.width = input$plot.line,l=20) +
        geom_line(data=chron_dat, aes(x=chron_dat[,1], y=chron_dat[,2]), colour = "red", size = input$plot.line+0.25, na.rm=T) +
        ylab("Standardised increment width") + xlab(x.lab) +
        scale_x_continuous(breaks = x.scale.bar(round(min(new[,1]),-1),round(max(new[,1]),-1)))


      if(is.null(N.plot.dat) || ncol(N.plot.dat)<2){
        plot2<-RingdateR_error_message(message="EPS Rbar window length must be greater than 5 and less than 66% of the total length of the series")

      } else {

        plot2<-ggplot()+
          geom_line(data=N.plot.dat, aes(x=N.plot.dat[,1], y=N.plot.dat[,4]), size=input$plot.line, na.rm=T)+
          geom_line(data=N.plot.dat, aes(x=N.plot.dat[,1], y=N.plot.dat[,5]), size=input$plot.line, na.rm=T, color="red") +
          R_dateR_theme(text.size = input$text.size, line.width = input$line.width,l=20)  +
          scale_x_continuous(breaks = x.scale.bar(round(min(new[,1]),-1),round(max(new[,1]),-1)), limits = c(min(new[,1]),max(new[,1]))) +
          geom_hline(yintercept = 0.85, colour = "red",linetype = 2, size=input$plot.line) + ylab("Rbar and EPS") + xlab("Year")

      }

      g1 <- ggplotGrob(plot1)
      g2<-  ggplotGrob(plot2)
      g<-rbind(g1, g2, size = "first")
      both <-  grid.draw(g)
      return(both)
    }
  }

  output$initiated_chron_plot<-renderPlot({
    plot_initiated_chron()
  }, height=1000)

  # set the x-axis scale
  observe({
    x <- suppressWarnings(min(as.numeric(chron_n_series()[,1])))

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <-suppressWarnings(min(as.numeric(chron_n_series()[,1])))

    # Can also set the label and select items
    updateNumericInput(session, "x_start",
                       value = x
    )
  })
  observe({
    x <-suppressWarnings(max(as.numeric(chron_n_series()[,1])))

    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- suppressWarnings(max(as.numeric(chron_n_series()[,1])))

    # Can also set the label and select items
    updateNumericInput(session, "x_end",
                       value = x
    )
  })

  #### check for errors in the ring count  ########

  # generate the missing ring plot
  plot_ring_error<- function(){
    if (is.null(chron_master_res_sort())){
      plot2<-RingdateR_error_message()
    }
    else if (is.null(ring_error())){
      plot2<- RingdateR_error_message(message="Insufficient overlap to perform running correlation analysis")
      return(plot2)
    } else {
      output_correls<-ring_error()
      # new<-detrending()

      s2<-input$chron_series
      series.names<-colnames(new)
      plot.title<- paste0("Mean chronology vs ", input$chron_series)
      y.lab=paste0("lag (years from mean chronology)")

      col_scale <- col_pal(input$chron_colour_scale)

      x_lims<-c(min(output_correls[,1], na.rm =T),max(output_correls[,1], na.rm =T))

      # Plot a heat map of the correlations
      plot2<-ggplot(output_correls, aes(x=output_correls[,1], y=output_correls[,2]), na.rm=TRUE) + geom_raster(aes(fill = output_correls[,3])) +
        R_dateR_theme(text.size = input$text.size, line.width = input$line.width) +
        scale_fill_gradientn(colours = col_scale , limits = c(-1,1)) +labs(fill = "Correl. (R)", x = "Years", y= y.lab)  +
        scale_y_continuous(breaks = seq(min(output_correls[,2]), max(output_correls[,2]), by = 2)) +
        scale_x_continuous(breaks = c(seq(min(x_lims), max(x_lims), by = 20)))
    }
    return(plot2)
  }


  # Generate the updated undated series from the pairwise analysis mode (i.e. remove series that have been dated)
  initiated_removed_frame<-function(){
    the.data<-undated$df_data

    remove.data<-colnames(initiate_chrono())

    if (length(remove.data)<length(colnames(the.data))){
      updated.undated<-remove_series(the.data,remove.data)
      updated.undated<-data.frame(c(1:nrow(updated.undated)),updated.undated)
    } else {
      Data<-c("All data dated in")
      updated.undated<-data.frame(Data)
    }

    return(updated.undated)
  }

  initiated_chron_correl_replace<-function(){
    if(is.null(initiate_chrono())){NULL
    } else {
      if(ncol(detrended_initiated_chrono())<=3){error<-data.frame(c(""))
      colnames(error)<-c("You need at least three series in the initiated chronology to be able to calculate correlations with replacement")
      return(error)  } else {
        res_tab<-correl_replace(detrended_initiated_chrono())
        return(res_tab)
      }
    }
  }

  output$initiated_chron_correl_replace<-renderTable({initiated_chron_correl_replace()})

  create_rwl_initiated<-function(){

    the_data<-initiate_chrono()

    row.names(the_data)<- the_data[,1]
    the_data<-the_data[,-1]
    return(the_data)
  }

  create_two_column_initiated<-function(){
    new.chrono<-detrended_initiated_chrono()
    year<-new.chrono[,1]
    mean_chron<-rowMeans(new.chrono[,-1], na.rm = T)
    compile<-data.frame(year, mean_chron)
    return(compile)
  }


  ######################Save data #############################

  output$create_initiated_chron_rwl<- downloadHandler(
    filename = function() {
      paste("updated_chronology_", Sys.Date(), ".rwl", sep="")
    },
    content = function(file) {
      suppressWarnings(write.rwl(create_rwl_initiated(), file))
    }
  )

  output$initiated_two_column <- downloadHandler(
    filename = function() {
      paste("mean_chronology", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(create_two_column_initiated(), file, row.names = F)
    }
  )

  output$remove_initiated_series <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(initiated_removed_frame(), file, row.names = F)
    }
  )

  output$pairwise_res_download <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(interseries_filt()[,-5], file, row.names = F)
    }
  )

  output$initiated.chrono.raw <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(initiate_chrono(), file, row.names = F)
    }
  )

  output$initiated.chrono.detrend <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(detrended_initiated_chrono(), file, row.names = F)
    }
  )

  output$download_detrend <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(detrending(), file, row.names = F)
    }
  )
  output$iterative_detrended <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(iterative.2$df_data, file, row.names = F)
    }
  )

  output$iterative_raw <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(align_undetrended_iterative_fun(), file, row.names = F)
    }
  )

  output$save_updat_undat <- downloadHandler(
    filename = function() {
      paste("data-", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(iterative_removed_fun()[,-1], file, row.names = F)
    }
  )

  ###################### Save plots ###################################

  output$downloadsingplt <- downloadHandler(
    filename = paste("detrended_Series_plot-", Sys.Date(), ".png", sep=""),
    content = function(file) {
      device <- function(..., width, height) {
        grDevices::png(..., width = width*2, height = height*1.5,
                       res = 300, units = "in"
        )
      }
      ggsave(file, plot = detrending.plot(), device = device)
    })

  output$pair_plot_download <- downloadHandler(
    filename = paste("Pairwise_line_plot", Sys.Date(), ".png", sep=""),
    content = function(file) {
      device <- function(..., width, height) {
        grDevices::png(..., width = width*2, height = height*0.75,
                       res = 300, units = "in"
        )
      }
      ggsave(file, plot = pairwise_plot_fun(font_size = input$text.size*0.7, axis_line_width = input$line.width*0.7, plot_line = input$plot.line*0.7), device = device)
    })

  output$pair_small_hm_downlaod <- downloadHandler(
    filename = paste("Small_Pairwise_heat_map-", Sys.Date(), ".png", sep=""),
    content = function(file) {
      device <- function(..., width, height) {
        grDevices::png(..., width = width*2, height = height*0.75,
                       res = 300, units = "in"
        )
      }
      ggsave(file, plot = plot_pairwise_small_hm(font_size = input$text.size*0.7, axis_line_width = input$line.width*0.7, plot_line = input$plot.line*0.7), device = device)
    })

  output$pair_bar_plot_download <- downloadHandler(
    filename = paste("Pairwise_bar_graph-", Sys.Date(), ".png", sep=""),
    content = function(file) {
      device <- function(..., width, height) {
        grDevices::png(..., width = width*2, height = height*0.75,
                       res = 300, units = "in"
        )
      }
      ggsave(file, plot = pairwise_bar_chart_fun(font_size = input$text.size*0.7, axis_line_width = input$line.width*0.7, plot_line = input$plot.line*0.7), device = device)
    })

  output$downloadsinghtmp <- downloadHandler(
    filename = paste("Full_pairwise_heatmap", Sys.Date(), ".png", sep=""),
    content = function(file) {
      device <- function(..., width, height) {
        grDevices::png(..., width = width*2.5, height = height*1.5,
                       res = 300, units = "in"
        )
      }
      ggsave(file, plot =  plotting_sing_hm(font_size = input$text.size*0.8, axis_line_width = input$line.width*0.8, plot_line = input$plot.line*0.8), device = device)
    })



  ##################################################
  ###### help messages #############################
  ##################################################

  # each observe event creates a response when a help button is clicked
  observeEvent(input$st_general_hlp,{
    st_general_hlp()
  })

  observeEvent(input$st_analysis_hlp,{
    st_analysis_hlp()
  })


  observeEvent(input$st_undate_hlp,{
    st_undate_hlp()
  })

  observeEvent(input$st_chron_hlp,{
    st_chron_hlp()
  })

  observeEvent(input$st_example_hlp,{
    st_example_hlp()
  })

  observeEvent(input$st_clear_data_hlp,{
    st_clear_data_hlp()
  })

  observeEvent(input$st_pair_hlp,{
    st_pair_hlp()
  })

  observeEvent(input$st_chron_run_hlp,{
    st_chron_run_hlp()
  })

  #####################################

  observeEvent(input$pw_general_hlp,{
    pw_general_hlp()
  })

  observeEvent(input$pw_plot_menu_hlp,{
    pw_plot_menu_hlp()
  })

  observeEvent(input$pw_stat_filt_hlp,{
    pw_stat_filt_hlp()
  })

  observeEvent(input$pw_name_filt_hlp,{
    pw_name_filt_hlp()
  })

  observeEvent(input$pw_prob_ck_hlp,{
    pw_prob_ck_hlp()
  })

  observeEvent(input$pw_align_hlp,{
    pw_align_hlp()
  })

  #####################################

  observeEvent(input$pw_heatmap_hlp,{
    pw_heatmap_hlp()
  })

  #####################################

  observeEvent(input$al_pw_general_hlp,{
    al_pw_general_hlp()
  })

  observeEvent(input$al_pw_menu_hlp,{
    al_pw_menu_hlp()
  })

  observeEvent(input$al_pw_download_hlp,{
    al_pw_download_hlp()
  })

  observeEvent(input$al_pw_correl_with_replacement_hlp,{
    al_pw_correl_with_replacement_hlp()
  })

  #########################################

  observeEvent(input$chrn_general_hlp,{
    chrn_general_hlp()
  })

  observeEvent(input$chrn_plot_ops_hlp,{
    chrn_plot_ops_hlp()
  })

  observeEvent(input$chrn_stat_filt_hlp,{
    chrn_stat_filt_hlp()
  })

  observeEvent(input$chrn_name_filt_hlp,{
    chrn_name_filt_hlp()
  })

  observeEvent(input$chrn_prob_ck_hlp,{
    chrn_prob_ck_hlp()
  })

  observeEvent(input$chrn_align_hlp,{
    chrn_align_hlp()
  })

  #########################################

  observeEvent(input$chrn_full_hm_hlp,{
    chrn_full_hm_hlp()
  })

  #########################################

  observeEvent(input$chrn_general_aligned,{
    chrn_general_aligned()
  })

  observeEvent(input$chrn_download_aligned_hlp,{
    chrn_download_aligned_hlp()
  })

  observeEvent(input$chrn_aligned_with_replacement_hlp,{
    chrn_aligned_with_replacement_hlp()
  })

  observeEvent(input$chrn_aligned_menu_hlp,{
    chrn_aligned_menu_hlp()
  })

  ######### functions to create the pop up help info
  st_chron_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Loading a chronology help"))),


                          div(style= "font-size:20pt;
                              text-align:justify;",

                              p("Chronology files can either be loaded as .RWL, .CSV or .xlsx files. RWL file should not have a header. The .CSV and .XLSX files
                                should be organized with the year values in the first column and then each individual series as a separate
                                column thereafter. The first row of the .CSV and .XLSX file should contain the sample IDs with the ID in the first column
                                being Year/date. RingdateR will detrend the individual series using the same method of for the pairwise data.
                                The arithmetic mean of the individual series is then calculated and used to compare against the pairwise samples."),

                              p("It is also possible to load a previously detrended master chronology in two column format (as a .CSV or .xlsx file).
                                RingdateR will automatically detect that a two column file has been loaded. Given the chronology is normally a dtrended series
                                ithe detrending aption box should be deselected (unless a secondary detrending is wanted).")



                          )
    )
    )
  }
  st_analysis_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Analysis options help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("If analysing multiple chronologies the analysis options should be set up before the data is loaded",
                                "this is because these settings will be instantly applied when the data is loaded. If comparing multiple",
                                "undated samples, then these settings can be adjusted following loading the data. This means that you",
                                "can evaluate the detrending by clicking on the detrending tab, before committing to run the analyses."),

                              tags$b(p("Detrending options")),
                              p(" Detrending is applied using the dplR detrend series function in R.",
                                " Residuals are calculated by dividing the ring width value against the detrending line value in each",
                                "respective year. This approach helps to mitigate ontogenetic trends in variance.",
                                "Power transform can be applied to stabilise variance through the time series.",
                                "For pre-whitened detrending, either select a short spline length (e.g. 5 or 7 years)",
                                " or select first difference detrending."),

                              tags$b(p("Lag interval")),
                              p("The lead lag analyses can be conducted over the entire period of overlap betwen each sample.",
                                "Alternatively, you can define a smaller limit to the lead and lags. Warning, defining a smaller",
                                "interval can lead samples having no period of overlap."),

                              tags$b(p("Select correlation window")),
                              p("the correlation window is used to define the period over which the running correlations are",
                                "calculated. As a result, this option should always be an odd number. If you put in an even number" ,
                                "If you select an even number RingdateR will automatically adjust it to be odd by adding a value of one")

                          )
    )
    )
  }
  st_undate_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Load data for Pairwise Analysis Mode "))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),

                              tags$b(p("Analyse individual series or multiple chronologies?")),
                              p("This dropdown box can be used to select what type of data you want to analyse in Pairwise
                                Analysis Mode. The options allowable are either comparing multiple individual series (e.g.
                                measurements from individual trees/shells) or comparing multiple chronologies.   "),

                              p(" If you plan to compare individual series against a chronology, the dropdown box should be set
                                to compare individual series. You should then load the individua series in the load series for
                                pairwise mode file browse menu, and then load the chronology for analysis in the load chronology box."),

                              tags$b(p( "Load data for Pairwise Analysis Mode")),
                              p(" RingdateR accepts data in a few different formats (RWL, XLSX, CSV, LPS and POS) and depending
                                on what format you load will automatically treat the data appropriately for that file format. "),

                              p( "If you plan to analyse multiple chronologies, these chronologies should be loaded as .RWL file formats.
                                 We plan to increase the number of acceptable file formats in the coming weeks. Each chronology should
                                 be loaded one at a time. Each time the file is loaded, the individual series in the RWL are detrended
                                 using the settings selected in the Analysis options and an arithmetic mean chronology calculated. At
                                 least two chronologies should be loaded."),

                              p("If you plan to analyse multiple individual series, you can use RWL, XLSX, CSV, LPS and POS file formats.
                                In the compare individual series mode, you can load only one RWL, XLSX and CSV file. These files should
                                contain all of the series you want to analyse. XLSX and CSV files should be formatted such that the
                                first column contains year values with the following columns containing the individual series to be analysed."),

                              p("LPS files (generated by Image Premier Pro) can contain multiple lines paths. RingedateR automatically detects
                                the lines and will name them as sample_ID_L1, sample_ID_L2 and so on. As LPS and POS files (from Coorecorder)
                                only contain data from a single sample, you can load multiple files. Year values for these file formats are
                                assigned from 1 through to N. "),

                              tags$b(p("Analyse undated chronologies?")),
                              p("Undated chronologies can be loaded as either .rwl, xlsx or .csv files. Data in the xlsx and csv The data should
                                in the format of first column containing increment or year value, in ascneding order, with each subsequent column
                                containing each individual series aligned by date. The first row of the file should contain the sample IDs. The
                                chronology files are instantly detrended when they are loaded so be sure to set the detrending options before
                                loading the data. The chronologies can either be compared against each other (in Pairwise Analysis Mode), or against
                                an existing dated chronology (loaded though the Load a dated chronololgy browser).")



                          )
    )

    )
  }
  st_general_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("General help and info"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("Version")),
                              p("You are currently running RingdateR V1.1 beta (30th September 2019)."),

                              tags$b(p("Bugs and updates")),
                              p("TThis version is a beta version for testing. Please let us know if there are any bugs
                                or features that you would like to be added to RingdateR. You can contact us by emailing
                                davidreynolds@email.arizona.edu"),

                              tags$b(p("Display problems")),
                              p("RingdateR ha been designed as a reactive webpage. If it is not currently displaying
                                properly on your screen you can rectify this situation by changing the zoom level within
                                your web browser using your browsers zoom options (ctrl and + or - buttons in Windows, or
                                Command and + or - button on Mac OS."),

                              tags$b(p("Quick help")),
                              p("Quick help buttons [I bouttons] have been placed throughout RingdateR to provide a quick
                                tops and basic probem shooting. We have also provided links to the more detailed help and
                                information about how RingdateR is going about the analysis either on
                                the Launch Page, and at the top of every Quick Help popup."),

                              tags$b(p("Privacy statement")),
                              p("RingdateR doesn’t store any user information. RingdateR online is run on a shinyapps.
                                io server, essentially, in the same way that a user runs an R session on their local computer.
                                This means that data uploaded into RingdateR online during a session will be deleted once the
                                session is finished (either by closing the browser window or clicking the kill switch on the
                                Start Page). RingdateR launcher does log the time that RingdateR launches. We do this so that
                                we can allocate server space to each user to optimize performance of the programme."
                              )
                          )
    )
    )
  }
  st_pair_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Starting Pairwise Analysis Mode Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align: justify;",

                              tags$b(p("General points")),
                              p("This button simply starts the pairwise analysis. If the analysis has started properly, then a progress
                                bar should appear on the screen. If the progress bar fails to appear there has likely been an error. If
                                an error occurs during loading it is likely the sample IDs will not appear in the Series to Analyse box.
                                You can also check a summary of the data that has been loaded by clicking on the Loaded Data tab in the
                                main menu bar. Here you will find summaries of both the individual series and chronologies that have been
                                loaded.
                                ")



                          )
    )
    )
  }
  st_example_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Example data Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              p("To provide easy testing of the programme we have added some example tree ring width data (Doug fir series).
                                The example data contains series for use in both the pairwise mode and chronology analysis modes. By clicking
                                use example data you can then go straight to clicking on run analysis in either pairwise or chronology mode boxes."),

                              p("The example data will only load if there is no other data in the programme. To clear the programme of loaded
                                data, click the Clear Data button (in the Step 3 box).")



                          )
    )
    )
  }
  st_clear_data_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Clear Data Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",


                              p("This box will contain a list of the series IDs for each of the individual series that has been loaded
                                for the pairwise analysis mode. If this box is empty, it means there is no data loaded. If you have
                                tried to load data and this box remains empty, it is likely there has been a problem with the loading of
                                the data. "),

                              p("Likely sources of errors in file loading include: the data being in the wrong order (years should go
                                from oldest, at the top, to most recent at the bottom), all data should be continuous and evenly spaced (annually resolved) with no
                                missing values (within series). For the most efficient comparison of undated series the data should all be organized such that the
                                earliest ring in each sample is aligned.
                                ")



                          )
    )
    )
  }

  pw_stat_filt_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              p("Use these options to filter the big results table shown below. These filters are only applied to the best
                                lag (first R, first P and first overlap)."),

                              p("If using the align data button (step four) then these statistical filters are automatically applied. it is
                                good practice to apply these filters ahead of running the align process to see which data will be aligned.
                                ")



                          )
    )
    )
  }
  pw_prob_ck_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("Problem samples are evaluated by aligning all the data selected in the main results table. An arithmetic
                                mean chronology is then calculated. Each sample is then compared to the mean chronology with replacement
                                (i.e. the chronology is recalculated with the corresponding sample removed). The correlation between each
                                sample and the chronology constructed from the other samples is then calculated over a set bin size with
                                a 50% overlap between bins."),

                              p("Bin size can have a significant impact on the results of these analyses. It is therefore important to
                                performing these analyses with a range of bin sizes."),

                              p("To perform these analysis both the statistics filter (step one) and sample ID filter (step 2; Filter
                                using series 1) must be applied. "),

                              p("There analyses flag samples that contain two types of problem. Some samples can be flagged as problematic
                                despite not actually having any errors in the ring counts/ measurements. This is due to the correlation
                                between the sample and the mean chronology fluctuates through time. These analyses also flags samples that
                                have missing/false rings. "),

                              p("Using the aligned data options, it is then possible to evaluate the problematic samples relative the mean
                                chronology of the samples that haven’t been flagged as problematic.
                                ")



                          )
    )
    )
  }
  pw_plot_menu_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Pairwise Analysis Mode Menu Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",


                              p("This menu controls the data that is displayed in the plots on the left. "),

                              p("Samples can be selected for plotting using either the manual sample selection method or by selecting
                                a row from the main results table at the bottom of the page. To switch between these options use the
                                [Selection options] drop down menu.."),

                              p("Once two series have been selected, series two (shown as the red line in the line plot) is aligned
                                in time relative to sample one. It is possible to control the alignment of the two samples using the
                                [select lag] drop down menu. Series two can be aligned to the lag with the best, second best or third
                                best correlation. Alternatively, it is possible to set a custom lag value. "),

                              p("The [Normalise data in the plot] checkbox standardizes the data plotted in the line plot. This
                                standardisation is only applied to the data being plotted in the line plot and does not impact any
                                of the statistics. "),

                              p("The [select colour scale] drop down box defines the colour scale of the running lead lag correlation
                                heatmap."),

                              p("The [adjust x-axis scale line plot] check box and corresponding numeric input boxes allow the
                                adjustment of the x-axis of the line plot.
                                ")



                          )
    )
    )
  }
  pw_name_filt_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("These options allow you to filter the main results table by sample ID. The [Filter using series 1] filters
                                the table based on the first column whilst [Filter using series 2] filters by series IDs in the second column.
                                To use the Problem sample checker, you must first filter the results table using the [Filter using series 1].
                                The statistics filter must also be applied.")



                          )
    )
    )
  }
  pw_heatmap_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Pairwise Correlaton Heatmap Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("The pairwise heat map page is designed to allow the generation of a running lead lag correlation heat
                                maps over the full range of correlations analysed. The range of the correlations can be set on the
                                Starting Point page (Step one)."),

                              p("To perform the analysis, simply select the names of the two series to be analysed from the drop-down
                                menu in the panel on the left, and then click the [Produce heat map] button."),

                              p("It is possible to change the X and Y axis options as well as the colour scale that is used using the
                                settings options displayed on the other panels.
                                ")



                          )
    )
    )
  }
  pw_general_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Pairwise Analysis Mode Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("This page contains all of the results of the pairwise amalyses. At the bottom of the page you will find a
                                results table containing all of the results for every pairwise comparison. This table shows the best three
                                possible matches between samples. This big results table is filterable either using statistics (correlation,
                                probability and period of overlap) or by using the sample IDs (Step 2). Alternatively, you can use the filter
                                buttons on the results table itself to show the best (or worst) pairwise results. RingdateR will show you three
                                plots for the pairwise results: a line plot of the two selected samples aligned in time, a running lead lag
                                correlation heat map plot and a bar chart of all the lags showing positive correlations. The running lead lag
                                correlation heat map displays the running correlations for lags between -10 and +9 years centred on the
                                selected lag period plotted in the line plot."),

                              p("RingdateR will show you three plots for the pairwise results: a line plot of the two selected samples
                                aligned in time, a running lead lag correlation heat map plot and a bar chart of all the lags showing
                                positive correlations. The running lead lag correlation heat map displays the running correlations for lags
                                between -10 and +9 years centred on the selected lag period plotted in the line plot."),

                              p("You can select which series are displayed in these plots using the menu on the right of the screen.
                                In this menu you can either directly select the two samples (using the manual sample selection method), or,
                                if you choose the “Select row from results table”, you can click on a row of the big results table and it
                                will bring up the plots associated with the corresponding pairwise comparison. The menu on the right of the
                                screen also displays a summary results table for the two selected samples. This menu system allows you to
                                change the lag that the second series is plotted with relative to sample one. The lag options are either the
                                lags with the best, second best and third best correlations. Alternatively, you can select a manual lag.
                                In manual lag you can set this to what ever value you like (providing there is enough overlap between the
                                samples to perform statistical analyses). All of the plots will automatically update.
                                ")



                          )
    )
    )
  }
  pw_align_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("This panel can be used to align data in time. The large results table must be filtered by both statistics
                                (Step 1) and by Series 1 ID (Step 2), and the Problem Sample check must be performed before the data can
                                be aligned. Once these steps have been completed, the data can be aligned using three options:"),

                              p("All Series: This option aligns all the data that are in the main results table. It will include any samples
                                that the problem checker has identified as being potential problems. On the Aligned Data Page it is then
                                possible to evaluate these problem samples against the mean chronology generated by arithmetically averaging
                                all the samples that don’t contain problems. To be able to evaluate problem samples, the aligned series must
                                contain at least three samples that contain no problems. "),

                              p("All series, excluding problem samples: This option will exclude the problem samples from the resulting
                                aligned data and resulting mean chronology. "),

                              p("Manual sample selection: This option will allow you to align any of the samples that are contained in
                                the large results table. "),

                              p("Unsurprisingly, at least two samples must be selected to be able to align the data.
                                ")



                          )
    )
    )
  }

  al_pw_menu_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Aligned data menu Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              p("This menu allows you to check if there are any remaining problematic samples in the aligned data set.
                                If any problematic samples are identified, you can then select the sample form the drop-down menu to
                                evaluate if the series compared to the arithmetic mean chronology calculated excluding the samples that
                                have been identified as problematic.  "),

                              p("As bin size can have a significant impact on the ability to identify whether series contain problems,
                                it is recommended that this analysis is repeated several times using different length bin sizes.")

                          )
    )
    )
  }
  al_pw_general_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("General aligned pairwsie Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual") , onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("This page shows the results of aligning the selected data from the Pairwise results page. The main
                                plot panel contains three tabs showing: "),

                              p("Aligned Data tab: Top plot) A plot showing the variability in each of the aligned series (black lines)
                                as well as the arithmetic mean chronology (red line). The bottom plot shows the running Rbar and EPS
                                statistics calculated using the running RWI function in dplR. It is possible to change the window length
                                of this plot using the numeric input box in the control panel on the right of the page. The default is 25
                                years with a 50% overlap between bins."),

                              p("Sample Depth plot Tab: This tab contains a plot displaying the position in time of each of the samples
                                that have been aligned. The names of each sample is displayed on the Y-axis on the right of the plot. If
                                you have evaluated for problematic samples (by using the button on the panel on the right of the page) any
                                problematic samples will be highlighted in red."),

                              p("Evaluate problematic samples tab: This tab contains both a line plot and a running correlation heat map
                                calculated between the selected problematic sample and the arithmetic mean chronology calculated with all
                                problematic samples excluded. To generate these plots, you should click the Evaluate for problem samples
                                button in the control panel on the right of the page. If the analysis detects problem samples, you can then
                                select which sample you want to evaluate from the [Select problem sample to evaluate] drop down menu and then
                                click the [evaluate problem sample] button. Similarly to the problem check analysis on the Pairwise Results
                                page, samples can be flagged as problems if they either contain periods with reduced correlation, or there
                                are obvious missing/false rings. ")

                          )
    )
    )
  }
  al_pw_download_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("Download aligned data Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",

                              tags$b(p("General points")),
                              p("These buttons let you download/save data from RingdateR in four options. "),

                              p("1.	The undetrended aligned series."),
                              p("2.	The detrended aligned series. "),
                              p("3.	Update the undated file with aligned series removed. "),
                              p("4.	Create rwl file. "),

                              p("Buttons one and two give you the option to download the aligned data from the
                                pairwise mode either as detrended or undetrended. These data will be in comma
                                separated value (.csv) format. "),
                              p("Button 3 will save a .CSV file of the undetrended data that were not aligned.
                                Any data that were aligned will not be included in this new file. This button
                                will work whether you initially loaded a single compiled file or multiple individual
                                files."),
                              p("Button 4 creates an .rwl file for use in COFECHA or other dendrochronology applications. ")



                          )
    )
    )
  }
  al_pw_correl_with_replacement_hlp<-function(){
    showModal(modalDialog(size = "l",
                          easyClose = T,
                          title = div(style= "font-size:20pt",
                                      tags$b(p("General aligned pairwsie Help"))),

                          actionButton("pdf", style= "font-size:20pt", p("For more deteailed help please download the RingdateR manual"), onclick="window.open('https://ringdater.github.io/ringdater/help.html', '_blank')" ),
                          div(style= "font-size:20pt;
                              text-align:justify;",


                              p("This panel contains a table summarising the mean correlation between each individual series and the mean
                                chronology calculated excluding that individual sample (i.e. with replacement). The correlations are
                                calculated over the entire period of overlap between the individual series and the mean chronology.  ")



                          )
    )
    )
  }

  ##################### Debug #######################################
  # Use to output a dataframe from the above functions to aid debugging
  output$debug<-renderTable({NULL})
  output$debug2<-renderTable({NULL})
} # end of server

shinyApp(ui = ui, server = shinyServer)





