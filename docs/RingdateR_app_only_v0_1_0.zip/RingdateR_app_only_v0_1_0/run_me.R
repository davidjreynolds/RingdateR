############################################################################
###########                      RingdateR                       ###########
############################################################################
#
# version 0.1.0
# 
# To run the app in Rstudio, click Run App button (in the top right corner of
# this window).The app will then automatically launch in your default  web browser.
#
# If not already installed in Rstudio, required packages will be automatically installed
# the first time the app is run. This may take a few minutes to complete.
#
# This line tells R where the working directory is for the app
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
#
# Now the script the load all of the files and package dependencies
source("app_data/ringdater_setup.R")

# These lines set some key options and then launches the app in your 
# default web browser
options(shiny.maxRequestSize = 50*1024^2)
registerDoParallel(cores=2)
runApp(list(ui = ui, server = RingServer), launch.browser = TRUE)
#
############################################################################
