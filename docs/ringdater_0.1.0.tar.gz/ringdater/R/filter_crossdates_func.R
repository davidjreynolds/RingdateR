#' RingdateR shiny server file
#'
#' This function filters the results table created by A dataframe created by lead_lag_analysis() function (lead_lag_analysis()[1])
#'
#' @keywords statistics tests
#' @param the_data A dataframe created by lead_lag_analysis() function (lead_lag_analysis()[1]). Must be a dataframe.
#' @param r_val A numeric value (>=0 and <=1). Correlation coefficient.
#' @param p_val A numeric value (>=0 and <=1). Probablility value.
#' @param overlap An integer >0. This value represents the period of overlap between samples.
#' @export
#' @examples
#' filter_crossdates()
filter_crossdates<- function(the_data, r_val = 0.5, p_val = 0.05, overlap = 50, target = NULL){

  # example check for parameter that should be a numeric between a set range. then sets the value to a default.
  if(class(r_val) != "numeric"){
    warning("Error in filter_crossdates(). r_val must be a numeric from 0 to 1. r_val set to 0.5.")
    r_val <- 0.5
  }
  if (r_val< 0 || r_val > 1){
    warning("Error in filter_crossdates(). r_val must be a numeric from 0 to 1. r_val set to 0.5.")
    r_val <- 0.5
  }
  if(class(p_val) != "numeric"){
    warning("Error in filter_crossdates(). p_val must be a numeric from 0 to 1. p_val set to 0.05.")
    p_val <- 0.05
  }
  # example check for parameter that should be a numeric between a set range. then sets the value to a default.
  if (p_val< 0 || p_val > 1){
    warning("Error in filter_crossdates(). p_val must be a numeric from 0 to 1. p_val set to 0.05.")
    p_val <- 0.05
  }
  if(class(overlap) != "numeric"){
    warning("Error in filter_crossdates(). overlap must be a numeric >0. overlap set to 50.")
    overlap <- 50
  }
  # example check for parameter that should be a numeric between a set range. then sets the value to a default.
  if (overlap <= 0){
    warning("Error in filter_crossdates(). overlap must be a numeric >0 . overlap set to 50.")
    overlap <- 50
  }
  # example check for a dataframe with at least 2 columns of data.
  if (class(the_data) != "data.frame"){
    warning("Error in filter_crossdates(). Required data are not a data.frame")
    return(NULL)
    # Check thre is enough data in the data.frame
  } else if (ncol(the_data)<=2){
    warning("Error in filter_crossdates(). Insufficient data to perform operation")
    return(NULL)
  } else {

    the_data<-subset(the_data, the_data[,7]>=r_val)
    the_data<-subset(the_data, the_data[,8]<=p_val)
    the_data<-subset(the_data, the_data[,9]>=overlap)
    results<-the_data

    if (!is.null(target)){
      tmp1<-subset(the_data, the_data[,1] == target)
      tmp2<-subset(the_data, the_data[,2] == target)

      if (nrow(tmp1)>1 && nrow(tmp2) <1){
        results<-tmp1
      } else if (nrow(tmp1)>1 && nrow(tmp2)>1){
        results<-rbind(tmp1,tmp2)
      } else if (nrow(tmp1)<1 && nrow(tmp2) >1){
        results<-tmp2
      }
    }
    if (ncol(results)<1){
      warning("Warning: The filtered crossdates resulted in no crossdates.")
      return(NULL)
      } else {
    return(results)}
  }
}
