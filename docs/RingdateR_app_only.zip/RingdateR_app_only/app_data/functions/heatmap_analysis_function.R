
heatmap_analysis<-function(the_data, s1, s2, neg_lag = -20, pos_lag = 20, win = 21, center = 0, complete = TRUE, sel_col_pal = 1, font_size = 12, axis_line_width = 1, plot_line = 1, leg_size = 1){

  if(is.null(the_data) || class(the_data) != "data.frame"){
    stop("Warning. Error in running_lead_lag. the_data is not a valid data.frame")
  }
  if(!s1 %in% colnames(the_data)){
    stop("Error in running_lead_lag: s1 is not a valid sample ID")
  }
  if(!s2 %in% colnames(the_data)){
    stop("Error in running_lead_lag: s2 is not a valid sample ID")
  }
  if(class(pos_lag) != "numeric" || pos_lag < neg_lag || pos_lag%%1 !=0){
    stop("Error in running_lead_lag: pos_lag should be an numeric integer with a value greater than leg_lag")
  }
  if(class(neg_lag) != "numeric" || neg_lag > pos_lag || neg_lag%%1 !=0){
    stop("Error in running_lead_lag: neg_lag should be an numeric integer with a value less than pos_lag")
  }
  if(class(win) != "numeric" || win%%1 !=0 || win < 5){
    stop("Error in running_lead_lag: win should be a numeric integer")
  }
  if(class(center) != "numeric" || center%%1 !=0){
    stop("Error in running_lead_lag: center should be an numeric integer")
  }
  if (class(complete) !="logical"){
    stop("Error in running_lead_lag: complete should be TRUE or FALSE")
  }
  if(class(sel_col_pal) != "numeric" || !sel_col_pal %in% 1:4){
    stop("Error in running_lead_lag: sel_col_pal should be a numeric integer 1:4")
  }
  if(class(font_size) != "numeric" || font_size%%1 !=0 || font_size <0){
    stop("Error in running_lead_lag: sel_col_pal should be a numeric integer >0")
  }
  if(class(axis_line_width) != "numeric" ||  axis_line_width <0){
    stop("Error in running_lead_lag: axis_line_width should be a numeric value >0")
  }
  if(class(plot_line) != "numeric" ||  plot_line <0){
    stop("Error in running_lead_lag: plot_line should be a numeric value >0")
  }
  if(class(leg_size) != "numeric" ||  leg_size <0){
    stop("Error in running_lead_lag: leg_size should be a numeric value >0")
  }

  plot.data <-  running_lead_lag(the_data=the_data, s1=s1, s2=s2, neg_lag = neg_lag + center, pos_lag = pos_lag + center, win = win, complete = complete)

  the_plot <- plotting_sing_hm(plot.data = plot.data, the_data=the_data, s1=s1, s2=s2, neg_lag = neg_lag + center, pos_lag = pos_lag + center, leg_size = leg_size)

  return(the_plot)
}
