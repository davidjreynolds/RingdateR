
files <- list.files("app_data/functions/")

for (i in 1: length(files)){
  source(paste0("app_data/functions/", files[i]))
  print(paste0("loaded ", files[i]))
}

packs <- c(
"data.table",
"DataCombine",
"DescTools",
"doParallel",
"dplR",
"dplyr",
"DT",
"ggplot2",
"grid",
"gridExtra",
"htmlwidgets",
"magrittr",
"readxl",
"rmarkdown",
"shiny",
"shinycssloaders",
"shinydashboard",
"shinyjs",
"shinyalert",
"shinyWidgets",
"stats",
"stringr",
"tidyselect",
"xml2",
"zoo")

print("loading packages...")

for (i in 1: length(packs)){
  if (!require(packs[i], character.only = TRUE)){
    install.packages(packs[i], character.only = TRUE)
    library(packs[i], character.only = TRUE)
  }
}
