#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' remove_series()
remove_series<-function(the.data=the.data, series.id = 1){

  for (i in 1:length(series.id)){
    series.2<-series.id[i]

    if(length(which(names(the.data) %in% paste0(parse(text=series.2)))) == 0){
      NULL
    } else {
    the.data<- the.data[ , -which(names(the.data) %in% paste0(parse(text=series.2)))]}
  }

  return(the.data)
}
