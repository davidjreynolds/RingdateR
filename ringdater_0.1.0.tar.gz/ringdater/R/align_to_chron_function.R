#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' align_to_chron()
align_to_chron<-function(the.data, chrono){

    the.data<-the.data[,-2] # the second column would contain the arithemtic mean chronology so remove it

     # set the date range for the new aligned data.frame
    min.the.data<- min(as.numeric(the.data[,1]))
    max.the.data<- max(as.numeric(the.data[,1]))
    chron.min<- min(chrono[,1])
    chron.max<- max(chrono[,1])

    # generate a new year colum that spans the full range of dates of the new chronology data
    new.years<-c(min(c(min.the.data,chron.min)):max(c(max.the.data,chron.max)))
    new.chrono<-data.frame(new.years)

    # add thechronology dsata to the data frame
    if(chron.min>min.the.data){
      NA.frame<-data.frame(matrix(NA, nrow = abs(chron.min-min.the.data), ncol = (ncol(chrono)-1)))
      colnames(NA.frame)<-colnames(chrono[,-1])
      chrono.tmp<-rbind(NA.frame,chrono[,-1])
      new.chrono<-cbind.fill(new.chrono,chrono.tmp, fill=NA)
    } else {new.chrono<-cbind.fill(new.chrono,chrono[,-1], fill=NA)}

    # add the new series to the data frame
    if(chron.min<min.the.data){
      NA.frame<-data.frame(matrix(NA, nrow = abs(min.the.data-chron.min), ncol = (ncol(the.data)-1)))
      colnames(NA.frame)<-colnames(the.data[,-1])
      the.data.tmp<-rbind(NA.frame,the.data[,-1])
      new.chrono<-cbind.fill(new.chrono,the.data.tmp, fill=NA)
    } else {new.chrono<-cbind.fill(new.chrono,the.data[,-1], fill=NA)}

    chron.names<-colnames(chrono)
    ser.nam<-colnames(the.data)[-1]
    colnames(new.chrono)<-c(chron.names,ser.nam)

    return(new.chrono)

}
