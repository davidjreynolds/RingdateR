#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' auto_correl()
auto_correl<- function(the_data = the_data){

n.series<-ncol(the_data)
A<-2
lag<-c()
res<-data.frame(c(0:10))


for (i in 1:(ncol(the_data)-1)){

  dat_1<- the_data[,A]
  dat_2<- the_data[,A]

  comb<-data.frame(dat_1,dat_2)
  comb<-subset(comb, complete.cases(comb))

  r_val<-cor(comb[,1], comb[,2])

  for (k in 1:10){

    NA_ser<-rep(NA,k)

    dat_1<- the_data[A]
    dat_2<- c(NA_ser, the_data[,A])

    comb<-cbind.fill(dat_1,dat_2)
    comb<-subset(comb, complete.cases(comb))

    r_val<-c(r_val,cor(comb[,1], comb[,2]))

  }

  res<-cbind(res, r_val)
  r_val<-c()
  A<-A+1

}
colnames(res)<-c("lag", colnames(the_data)[-1])

return(res)

}
