#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' x.scale.bar()
x.scale.bar<-function(x.min,x.max){

if(x.max-x.min>1000){
  breaks<-seq(x.min, x.max, by = 100) # 100
}  else if(x.max-x.min>500){
   breaks<-seq(x.min, x.max, by = 50)  # 50
   } else if(x.max-x.min>250){
     breaks<-seq(x.min, x.max, by = 20)
   } else if (x.max-x.min>50){
     breaks<-seq(x.min, x.max, by = 10)
   } else if (x.max-x.min>20){
     breaks<-seq(x.min, x.max, by = 5)
   } else{breaks<-seq(x.min, x.max, by = 2)}

return(breaks)
}
