#' Line plot of two samples adjusted for lag
#'
#' PLot two timeseries and adjust the lag of the second series
#' @keywords ;ead-lag analysis
#' @export
#' @examples
#' line_plot()
line_plot<-function(the_data, series_1_nm, series_2_nm, lag = 0){

  series_1<-data.frame(the_data[,1], the_data[[series_1_nm]])
  series_2<-data.frame(the_data[,1], the_data[[series_2_nm]])

  series_1<-subset(series_1, (complete.cases(series_1)))
  series_2<-subset(series_2, (complete.cases(series_2)))

  series_2[,1]<-series_2[,1]+lag

  plot.title<-paste0(series_1_nm, " (black line) and ", series_2_nm, " lagged by ", lag, " years (red line)" )

  x.lab<- "Years"

  plot1<-ggplot()+
    geom_line(data = series_1, aes(x=series_1[,1], y=series_1[,2]), na.rm=TRUE, colour="black", size = 0.5) + labs(title = plot.title) +
    geom_line(data = series_2, aes(x=series_2[,1], y=series_2[,2]), na.rm=TRUE, colour="red", size = 0.5) + R_dateR_theme(text.size = 12, line.width = 1) +
    ylab("Standardised increment width") + xlab(x.lab) +
    scale_x_continuous(breaks = x.scale.bar(round(min(min(series_1[,1]),min(series_2[,1])), -1), round(max(max(series_1[,1]),max(series_2[,1])), -1)))

  return(plot1)
}
