
filter_crossdates<-function(the_data, r_val = 0.5, p_val = 0.05, overlap = 50, target = NULL){

  if (class(the_data) !=  "data.frame"){
    stop("Error in filter_crossdates: the_data is not of class data.frame")
  }
  if (class (r_val) != "numeric" || r_val < 0 || r_val > 1){
    stop("Error in filter_crossdates: r_val should be numeric value > 0 and < 1")
  }
  if (class (p_val) != "numeric" || p_val < 0 || p_val > 1){
    stop("Error in filter_crossdates: p_val should be numeric value > 0 and < 1")
  }
  if (class (overlap) != "numeric" || overlap %%1!=0 || overlap < 1){
    stop("Error in filter_crossdates: overlap should be numeric integer")
  }
  if (!target %in% the_data[,1] || !target %in% the_data[,2]){
    stop("Error in filter_crossdates: target must be a valid sample ID")
  }

  tmp_1<-subset(the_data,(the_data[,1]==target))
  tmp_2<-subset(the_data,(the_data[,2]==target))

  the_data<-rbind(tmp_1,tmp_2)

  the_data<-subset(the_data,(the_data[,7]>=r_val) & (the_data[,8]<=p_val) & (the_data[,9]>=overlap))

  the_data[,7]<-signif(the_data[,7],3)
  the_data[,8]<-signif(the_data[,8],5)
  the_data[,11]<-signif(the_data[,11],3)
  the_data[,12]<-signif(the_data[,12],5)
  the_data[,15]<-signif(the_data[,15],3)
  the_data[,16]<-signif(the_data[,16],5)
  return(the_data)
}

