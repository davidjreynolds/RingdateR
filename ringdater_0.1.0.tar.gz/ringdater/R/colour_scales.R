
#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' col_pal()
col_pal <- function(colour_scale = 1){

  if(colour_scale == 1){col_scale <- c("#4575b4","#e0f3f8","#d73027")
  } else if(colour_scale == 2){col_scale <- c("#ffffff", "#ffffff", "#ca0020")
  } else if(colour_scale == 3){col_scale <- c("#ffffff","#ffffff","#ffffff", "#0571b0","#00216d")
  } else if(colour_scale == 4){col_scale <- c("#ffffff","#ffffff", "#000000")
  }

 return(col_scale)

}
