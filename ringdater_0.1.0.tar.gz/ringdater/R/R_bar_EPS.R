#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' R_bar_EPS()

R_bar_EPS<-function(the.data = the.data, window = 25){

row.names(the.data)<-the.data[,1]

test<-rwi.stats.running(the.data[,-1], method ="pearson",running.window = TRUE,
                        window.length = window,
                        window.overlap = floor(window / 2),
                        first.start = NULL,
                        round.decimals = 3,
                        zero.is.missing = TRUE)

res.tab<-data.frame(test$mid.year,test$n.trees,test$n,test$rbar.tot,test$eps)
return(res.tab)
}
