#' RingdateR shiny server file
#'
#' This function creates the shiny user interface
#' @keywords GUI
#' @export
#' @examples
#' lead_lag()
lead_lag<-function(the.data = the.data,  neg_lag = -20, pos_lag = 20, multiple = T, complete=F){

  de.tnd<-the.data
  de.tnd<- subset(de.tnd, !is.na(de.tnd[,1]))

  N_limit<-5
  shell_IDs<-colnames(de.tnd)
  no.series<-ncol(de.tnd)
  pos_lag<-pos_lag
  neg_lag<-neg_lag

  results_tab<-data.frame()

  a<-2
  b<-a+1

  cross_dat_res<-data.frame()
  repeat{
    repeat{
      #extract the data for the analysis
      years<-de.tnd[,1]
      shell_a<-de.tnd[,a]
      shell_b<-de.tnd[,b]
      run.cor.dat<-data.frame(years,shell_a,shell_b)

      shell_a_lim<-data.frame(years,de.tnd[,a])
      shell_b_lim<-data.frame(years,de.tnd[,b])
      shell_a_lim<-subset(shell_a_lim, (!is.na(shell_a_lim[,1])) & (!is.na(shell_a_lim[,2])))
      shell_b_lim<-subset(shell_b_lim, (!is.na(shell_b_lim[,1])) & (!is.na(shell_b_lim[,2])))

      shell_a_d.of.set<-min(shell_a_lim[,1])
      shell_a_d.of.d<-max(shell_a_lim[,1])

      shell_b_d.of.set<-min(shell_b_lim[,1])
      shell_b_d.of.d<-max(shell_b_lim[,1])

      # set up the data for the analysis
      pos_lag_lim<-shell_a_d.of.d-shell_b_d.of.d+length(shell_b_lim[,2])-N_limit
      neg_lag_lim<--(shell_b_d.of.set-shell_a_d.of.set+length(shell_b_lim[,2]))+N_limit

      if(complete){pos_lag<-pos_lag_lim   # tells the analysis to run over the maximum allowable lead-lag
      neg_lag<-neg_lag_lim}

      if (pos_lag>pos_lag_lim){max_pos_lag<-pos_lag_lim
      } else {max_pos_lag<-pos_lag}

      if (neg_lag<neg_lag_lim){max_neg_lag<-neg_lag_lim
      } else {max_neg_lag<-neg_lag}

      correction <- max_pos_lag-max_neg_lag # the correction will be used to adjust the P value to account for the number of correlations calculated

      #neg lag first
      lag<-(max_neg_lag)
     years<-as.numeric(years)
       repeat {
      if(lag<=-1){
        NA_ser<-rep(NA,abs(lag))
        mod_ser_1<-c(NA_ser,shell_a)
        mod_ser_2<-c(shell_b,NA_ser)
        analysis.data<-cbind.fill(mod_ser_1,mod_ser_2, fill = NA)

      } else if (lag==0){
        mod_ser_1<-shell_a
        mod_ser_2<-shell_b
        analysis.data<-cbind.fill(mod_ser_1,mod_ser_2, fill = NA)

      } else if(lag>=1){
        NA_ser<-rep(NA,lag)
        mod_ser_1<-c(shell_a,NA_ser)
        mod_ser_2<-c(NA_ser,shell_b)
        analysis.data<-cbind.fill(mod_ser_1,mod_ser_2, fill = NA)

      }
        ser.2_dates<-data.frame(years,shell_b)
        ser.2_dates<-subset(ser.2_dates, complete.cases(ser.2_dates))
        ser.2_dates[,1]<-ser.2_dates[,1]+lag

        analysis.data<-subset(analysis.data, complete.cases(analysis.data))

        cor_test<-cor.test(analysis.data[,1],analysis.data[,2])
        p_val<-cor_test$p.value * correction
        r_val<-cor_test$estimate
        t_val<-cor_test$statistic
        over<-round(length(analysis.data[,1]),0)

        res_tmp<-data.frame(lag, r_val, p_val, t_val, over, min(ser.2_dates[,1]), max(ser.2_dates[,1]))
        colnames(res_tmp)<-c("lag", "R Val", "P Val", "T_val", "Overlap", "First ring", "Last ring")
        results_tab<-rbind(results_tab,res_tmp)
        colnames(results_tab)<-c("lag", "R Val", "P Val", "T_val", "Overlap", "First ring", "Last ring")
        lag<-lag+1
        mod_ser_1<-NULL
        mod_ser_2<-NULL
        ser.2_dates<-NULL

        if (lag>=max_pos_lag){break}
      }


      ######################################################
      ### Produce a results table of the best crossdates ###
      ######################################################
      results_tab<-subset(results_tab, (results_tab[,2]>0))
      ordered<-results_tab[order(results_tab[,3]),]

      chron.strt<-min(de.tnd[,1])
      chron.end<-max(de.tnd[,1])
      chron.rang<-c(chron.strt,chron.end)

      series.a.range<-c(shell_a_d.of.set,shell_a_d.of.d)

      tab_names<-c("Series #1", "Series #2","First ring", "Last ring", "col", "1st lag (years)", "1st R", " 1st P", "1st Overlap", "2nd lag (years)", "2nd R", "2nd P", "2nd Overlap", "3rd lag (years)", "3rd R", "3rd P", "3rd Overlap")

      shell_a_date_rang<-data.frame(shell_IDs[a],shell_IDs[a],shell_a_d.of.set,shell_a_d.of.d,a,c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA), stringsAsFactors = FALSE)
      colnames(shell_a_date_rang)<-tab_names
      if(b==3){cross_dat_res<-rbind(cross_dat_res,shell_a_date_rang)
      cross_dat_res_tmp<-data.frame(shell_IDs[a], shell_IDs[b], ordered[1,6], ordered[1,7],b, ordered[1,1], ordered[1,2], ordered[1,3], ordered[1,5], ordered[2,1], ordered[2,2], ordered[2,3], ordered[2,5], ordered[3,1], ordered[3,2], ordered[3,3], ordered[3,5], stringsAsFactors = FALSE)
      colnames(cross_dat_res_tmp)<-tab_names
      cross_dat_res<-rbind(cross_dat_res,cross_dat_res_tmp)
      } else if (b==a+1){
        cross_dat_res<-rbind(cross_dat_res,shell_a_date_rang)
        cross_dat_res_tmp<-data.frame(shell_IDs[a], shell_IDs[b], ordered[1,6], ordered[1,7], b, ordered[1,1], ordered[1,2], ordered[1,3], ordered[1,5], ordered[2,1], ordered[2,2], ordered[2,3], ordered[2,5], ordered[3,1], ordered[3,2], ordered[3,3], ordered[3,5], stringsAsFactors = FALSE)
        colnames(cross_dat_res_tmp)<-tab_names
        cross_dat_res<-rbind(cross_dat_res,cross_dat_res_tmp)
      } else {
        cross_dat_res_tmp<-data.frame(shell_IDs[a], shell_IDs[b], ordered[1,6], ordered[1,7], b, ordered[1,1], ordered[1,2], ordered[1,3], ordered[1,5], ordered[2,1], ordered[2,2], ordered[2,3], ordered[2,5], ordered[3,1], ordered[3,2], ordered[3,3], ordered[3,5], stringsAsFactors = FALSE)
        colnames(cross_dat_res_tmp)<-tab_names
        cross_dat_res<-rbind(cross_dat_res,cross_dat_res_tmp)
      }
      results_tab<-data.frame() # clear the results tab
      b<-b+1
      if(b>no.series){break}}
    cross_dat_res_tmp<-data.frame(c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA),c(NA), c(NA), c(NA), stringsAsFactors = FALSE)
    colnames(cross_dat_res_tmp)<-tab_names

    cross_dat_res<-rbind(cross_dat_res,cross_dat_res_tmp)

    if (multiple){
      a<-a+1
      b<-a+1
      if(a>=no.series){break}
    } else{break}
  }

  cols.num <- seq(3,17, by =1)
  cross_dat_res[cols.num] <- sapply(cross_dat_res[cols.num],as.numeric)

  colnames(cross_dat_res)<-tab_names

  return(cross_dat_res)

}
