

detrending.plot.fun<- function(undet.data, first_series, detrending_select = 3, splinewindow = 21, font_size = 12, axis_line_width = 1, plot_line = 1){

  if (class(undet.data) != "data.frame"){
    stop("Error in detrending.plot.fun: undet.data must be a data.frame")
  }
  if (!first_series %in% colnames(undet.data)){
    stop("Error in detrending.plot.fun: first_series must be a valid sample ID contained as a column name in undet.data")
  }
  if (!detrending_select %in% 1:7){
    stop("Error in detrending.plot.fun: detrending_select must be an integer between 1 and 7.")
  }
  if (!class(splinewindow) == "numeric" || splinewindow < 0){
     stop("Error in detrending.plot.fun: splinewindow must be an integer.")
   }
  if (!class(font_size) == "numeric" && font_size%%1!=0){
    stop("Error in detrending.plot.fun: font_size must be an integer.")
  }
  if (!class(axis_line_width) == "numeric" || axis_line_width <0){
    stop("Error in detrending.plot.fun: axis_line_width must be of class numeric and >0.")
  }
  if (!class(plot_line) == "numeric" || plot_line <0){
    stop("Error in detrending.plot.fun: plot_line must be of class numeric and >0.")
  }

  # Get undetrended data
  un.det.years       <-undet.data[,1]
  undet.data         <-undet.data[[first_series]]
  undet.data         <-comb.NA(un.det.years,undet.data, fill = NA)
  undet.data         <-subset(undet.data,complete.cases(undet.data))

  det_nd<- normalise(undet.data, detrending_select = detrending_select, splinewindow = splinewindow)

  curve<- detcurves(series_data = undet.data, detrending_select = detrending_select, splinewindow = splinewindow)

  raw_auto <-auto_correl(undet.data)
  det_aut<- auto_correl(det_nd)

  x.lab<-"Increment number"

  plot1<- ggplot()+
    geom_line(data = undet.data, aes(x = undet.data[,1], y = undet.data[,2]), na.rm=TRUE, alpha =0.75, size = plot_line) +
    geom_line(data = curve, aes(x = curve[,1], y = curve[,2]), na.rm=TRUE, size = plot_line+0.5)+
    R_dateR_theme(text.size = font_size, line.width = axis_line_width,l=20) +
    labs(title = paste0(first_series, " raw data. Thick black line = the detrneding curve applied")) + ylab("Increment width") + xlab(x.lab) +
    scale_x_continuous(breaks = x.scale.bar(min(as.numeric(undet.data[,1])), max(as.numeric(undet.data[,1]))))

  plot2<- ggplot()+
    geom_line(data = det_nd, aes(x = det_nd[,1], y = det_nd[,2]), na.rm=TRUE, alpha =1, size = plot_line, colour = "red") +
    R_dateR_theme(text.size = font_size, line.width = axis_line_width,l=20) +
    labs(title = "Detrended data") + ylab("Increment width") + xlab(x.lab) +
    scale_x_continuous(breaks = x.scale.bar(min(as.numeric(undet.data[,1])), max(as.numeric(undet.data[,1]))))

  plot3 <- ggplot()+
    geom_line(data = raw_auto, aes(x = raw_auto[,1], y = raw_auto[,2]), na.rm=TRUE, size = plot_line) +
    geom_line(data = det_aut, aes(x = det_aut[,1], y = det_aut[,2]), na.rm=TRUE, size = plot_line, colour = "red") +
    R_dateR_theme(text.size = font_size, line.width = axis_line_width,l=20) +xlab("lag (Year)") + ylab("Correl. (R)") +
    labs(title="Black line = raw data auto correlation; Red line = detrended data autocorrelation") +
    scale_x_continuous(breaks = c(0:10))

  g1 <- ggplotGrob(plot1)
  g2<-  ggplotGrob(plot2)
  g3<-  ggplotGrob(plot3)

  g<-rbind(g1, g2, g3, size = "first")
  both <- grid.draw(g)
  return(both)
 }
