#' RingdateR shiny server file
#'
#' This function filters the results table created by A dataframe created by lead_lag_analysis() function (lead_lag_analysis()[1])
#'
#' @keywords statistics tests
#' @param the_data A dataframe created by lead_lag_analysis() function (lead_lag_analysis()[1]). Must be a dataframe.
#' @param r_val A numeric value (>=0 and <=1). Correlation coefficient.
#' @param p_val A numeric value (>=0 and <=1). Probablility value.
#' @param overlap An integer >0. This value represents the period of overlap between samples.
#' @export
#' @examples
#' filter_crossdates()
filter_crossdates<- function(the_data, r_val = 0.5, p_val = 0.05, overlap = 50, target = NULL){
  the_data<-subset(the_data, the_data[,7]>=r_val)
  the_data<-subset(the_data, the_data[,8]<=p_val)
  the_data<-subset(the_data, the_data[,9]>=overlap)
  results<-the_data

  if (!is.null(target)){
    tmp1<-subset(the_data, the_data[,1] == target)
    tmp2<-subset(the_data, the_data[,2] == target)

    if (nrow(tmp1)>1 && nrow(tmp2) <1){
      results<-tmp1
    } else if (nrow(tmp1)>1 && nrow(tmp2)>1){
      results<-rbind(tmp1,tmp2)
    } else if (nrow(tmp1)<1 && nrow(tmp2) >1){
      results<-tmp2
    }
  }

  return(results)
}
