#' Run RingdateR as a shiny app
#'
#' This function runs RingdateR as a shiny app
#' @keywords Shiny crossdating app
#' @export
#' @examples
#' run_ringdater()
run_ringdater<-function(){
  options(shiny.maxRequestSize = 50*1024^2)
  doParallel::registerDoParallel(cores=2)
  shinyApp(ui = ui, server = shinyServer)
}
