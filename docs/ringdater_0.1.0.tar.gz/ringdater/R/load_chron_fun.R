#' Load single chronology as a data frame
#'
#' This function creates a dataframe containing the data from a dated chronology.
#' @keywords RingdateR
#' @param file A  files path as a character string
#' @export
#' @examples
#' load_chron(file)
load_chron<- function(file){

  file_detect<-function(x,n){
    substr(x, nchar(x)-n+1, nchar(x))
  }

  # Detect the file format
  ftype<-file_detect(file,3)

  if(ftype=="rwl"){
   chron_loading_df_data<-read.rwl(file)
   chron_loading_df_data <- as.data.frame(chron_loading$df_data)
   chron_loading_df_data <- cbind.data.frame(as.numeric(row.names(chron_loading$df_data)),chron_loading$df_data)
    row.names(chron_loading$df_data)<-c()
  } else if (ftype=="csv"){
   chron_loading_df_data<-read.csv(file, header = T, stringsAsFactors = F)
  } else if (ftype=="lsx"){
   chron_loading_df_data<-as.data.frame(read_excel(file, sheet = 1, na ="NA" ))
  } else if (ftype=="txt"){
   chron_loading_df_data<-read.csv(file, header = T, sep = "/t", stringsAsFactors = F)
  }

  return(chron_loading_df_data)
}
