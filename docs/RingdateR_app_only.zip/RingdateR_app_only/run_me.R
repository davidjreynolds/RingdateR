############################################################################
###########                      RingDateR                       ###########
############################################################################
#
# version 0.1.0 
# 3-3-2020
#
# To run the app in Rstudio, click Run App button (in the top right corner of 
# this window).The app will then automatically launch in your web browser.
#
# If not already installed in Rstudio, required packages will be automatically installed
# the first time the app is run,
#
# This line tells R where the working directory is for the app
setwd(dirname(parent.frame(2)$ofile))
#
# This line launches the app in your default web browser
runApp("app_data", launch.browser = T)
#
############################################################################
