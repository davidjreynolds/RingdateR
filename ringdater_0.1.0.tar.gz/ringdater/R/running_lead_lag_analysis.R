#' running lead_lag analysis
#'
#' This function rperforms running lead-lag correlation analysis between two timeseries
#' @keywords pairwise_lead_lag
#' @param the_data A dataframe containing the timeseries. First column should contain dates.
#' @param s1 the name of a sample - must match a column name exactly
#' @param s2 the name of a sample - must match a column name exactly
#' @param neg_lag An integer
#' @param pos_lag An integer
#' @param complete A boolean to classify whther to run the lead-lag over the maximum range of leads and lags
#' @param win The window with which the running correlations are calculated over
#' @export
#' @examples
#' running_lead_lag()
running_lead_lag<-function(the_data, s1, s2, neg_lag = -20, pos_lag = 20, win = 21, complete = TRUE){
  if(is.null(the_data)){return(NULL)
  } else {

    even_odd<- win %% 2 == 0 # check that the correlation window is odd.
    if(even_odd) {win<-as.numeric(win)+1 # If it is even add 1 to make it odd.
    } else {win<-win}

    a<-the_data[s1]
    b<-the_data[s2]
    the_data<-data.frame(the_data[,1],a,b, stringsAsFactors = T)
    colnames(the_data)<-c("years","A","B")
    series_ID<-colnames(the_data)

    N_limit<-win

    ###########################################################

    run_cor_res<-data.frame()

    #extract the data for the analysis
    years<-the_data[,1]
    series_a<-the_data[,2]
    series_b<-the_data[,3]
    run.cor.dat<-data.frame(years,series_a,series_b)

    ser_a_len<-length(subset(series_a, (!is.na(series_a))))
    ser_b_len<-length(subset(series_b, (!is.na(series_b))))

    pos_lag_lim<- max(c(ser_a_len,ser_b_len))
    neg_lag_lim<- -max(c(ser_a_len,ser_b_len))

    if(complete){pos_lag<-pos_lag_lim   # tells the analysis to run over the maximum allowable lead-lag
    neg_lag<-neg_lag_lim}

    if (pos_lag>pos_lag_lim){max_pos_lag<-pos_lag_lim
    } else {max_pos_lag<-pos_lag}

    if (neg_lag<neg_lag_lim){max_neg_lag<-neg_lag_lim
    } else {max_neg_lag<-neg_lag}

    # set up the data for the analysis

    lag<-max_neg_lag

    repeat {
 #     progress$set(value = prog_count)
      if(lag<=-1){
        NA_ser<-rep(NA,abs(lag))
        yr_mod<-c(NA_ser,years)
        mod_ser_1<-c(NA_ser,series_a)
        mod_ser_2<-c(series_b,NA_ser)
        analysis.data<-cbind.fill(mod_ser_1,mod_ser_2, fill = NA)
      } else if (lag==0){
        yr_mod<-years
        mod_ser_1<-series_a
        mod_ser_2<-series_b
        analysis.data<-cbind.fill(mod_ser_1,mod_ser_2, fill = NA)
      } else if(lag>=1){
        NA_ser<-rep(NA,lag)
        yr_mod<-c(years,NA_ser)
        mod_ser_1<-c(series_a,NA_ser)
        mod_ser_2<-c(NA_ser,series_b)
        analysis.data<-cbind.fill(mod_ser_1,mod_ser_2, fill = NA)
      }

      len_test<-subset(analysis.data, complete.cases(analysis.data[,1:2]))

      if(nrow(len_test)<=win){NULL

      } else {
        cor_test<-rollcor(analysis.data[,1],analysis.data[,2], width = win, show =F)
        cor_year<-rollmean(yr_mod, k = win)
        lag_ser<- rep(lag,length(cor_year))

        run_cor_tmp<-cbind.fill(cor_year, lag_ser, cor_test, fill = NA)
        run_cor_tmp<-subset(run_cor_tmp, complete.cases(run_cor_tmp))
        colnames(run_cor_tmp)<-c("year", "lag", "R val")

        run_cor_res<-rbind(run_cor_res,run_cor_tmp)
        colnames(run_cor_res)<-c("year", "lag", "R val")

        mod_ser_1<-NULL
        mod_ser_2<-NULL
      }
      if (lag>=max_pos_lag){break}
      lag<-lag+1
 #     prog_count<-prog_count+1

    }
    if(nrow(run_cor_res)<15){run_cor_res<-NULL}

    return(run_cor_res)
    run_cor_res<-data.frame(NULL)}
}

#' Plot running lead_lag analysis
#'
#' This function plots the running lead_lag analysis
#' @keywords pairwise_lead_lag
#' @param plot.data a three column data frame containing the results from the running_lead_lag function
#' @param the_data A dataframe containing the timeseries. First column should contain dates.
#' @param s1 the name of a sample - must match a column name exactly
#' @param s2 the name of a sample - must match a column name exactly
#' @param neg_lag An integer
#' @param pos_lag An integer
#' @param font_size The size of the font (numeric)
#' @param axis_line_width The width of the axis (numeric)
#' @param plot_line The width of the line (numeric)
#' @param sel_col_pal The colour pallate to use (numeric)
#' @export
#' @examples
#' plotting_sing_hm()
plotting_sing_hm<- function(plot.data , the_data, s1, s2, font_size = 12, axis_line_width = 0.5, plot_line = 0.5, neg_lag = -20, pos_lag = 20, sel_col_pal = 1){
  if(is.null(plot.data)){return(warning("Insufficient overlap to perform running correlation analysis"))
  } else {

    new<-the_data

    series.names<-colnames(new)

    plot.title<- paste0(s1, " vs ", s2)
    y.lab<- paste0("lag (years from ", s1, ")")

    x.lab<-"Year"

    col_scale <- col_pal(sel_col_pal)

    # Plot a heat map of the correlations

    plot2<-ggplot(plot.data, aes(x=plot.data[,1], y=plot.data[,2]), na.rm=TRUE) + geom_raster(aes(fill = plot.data[,3])) + R_dateR_theme(text.size = font_size, line.width = axis_line_width) +
      scale_fill_gradientn(colours = col_scale, limits = c(-1,1)) +labs(fill = "Correl. (R)", x = x.lab, y= y.lab, title=plot.title) +
      scale_x_continuous(breaks = x.scale.bar(round(min(plot.data[,1]),-1), round(max(plot.data[,1]),-1))) +
      scale_y_continuous(breaks = y.scale.bar(min(plot.data[,2]),max(plot.data[,2])))

    return(plot2)
  }
}

#' running lead_lag analysis
#'
#' This function rperforms the full running lead-lag analysis and produces a plot of the results
#' @keywords pairwise_lead_lag
#' @param the_data A dataframe containing the timeseries. First column should contain dates.
#' @param s1 the name of a sample - must match a column name exactly
#' @param s2 the name of a sample - must match a column name exactly
#' @param neg_lag An integer
#' @param pos_lag An integer
#' @param complete A boolean to classify whther to run the lead-lag over the maximum range of leads and lags
#' @param win The window with which the running correlations are calculated over
#' @param font_size The size of the font (numeric)
#' @param axis_line_width The width of the axis (numeric)
#' @param plot_line The width of the line (numeric)
#' @param sel_col_pal The colour pallate to use (numeric)
#' @export
#' @examples
#' running_lead_lag()
run_lead_lag_analysis<-function(the_data, s1, s2, neg_lag = -20, pos_lag = 20, win = 21, complete = TRUE, sel_col_pal = 1, font_size = 12, axis_line_width = 1, plot_line = 1){

  plot.data <-  running_lead_lag(the_data=the_data, s1=s1, s2=s2, neg_lag = neg_lag, pos_lag = pos_lag, win = win, complete = complete)

  the_plot <- plotting_sing_hm(plot.data = plot.data, the_data=the_data, s1=s1, s2=s2, neg_lag = neg_lag, pos_lag = pos_lag)

  return(the_plot)
}



