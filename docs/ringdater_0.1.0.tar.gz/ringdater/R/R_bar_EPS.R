#' Calculate the Rbar and EPS of a chronology
#'
#' This function uses dplR to calculate the Rbar and EPS of a chronology
#' @keywords Rbar EPS chronology
#' @param the.data A data.frame holding individual series in the aligned chronology
#' @param window A numeric integer used to calculate the running Rbar and EPS values over.
#' @export
#' @examples
#' R_bar_EPS(the.data, window = 25)

R_bar_EPS<-function(the.data, window = 25){

  run <- TRUE

#  if (class(the.data) != "data.frame"){
#    warning("Error in correl_replace(). Required data are not a data.frame")
#    run <- FALSE
#    # Check thre is enough data in the data.frame
#  } else if (ncol(the_data)<=2){
#    warning("Error in correl_replace(). Insufficient data to calculate correlations")
#    run <- FALSE
#  }

#  if (class(window) != "numeric"){
#    run<- FALSE
#  }

  if (run){
    row.names(the.data)<-the.data[,1]

    test<-rwi.stats.running(the.data[,-1], method ="pearson",running.window = TRUE,
                            window.length = window,
                            window.overlap = floor(window / 2),
                            first.start = NULL,
                            round.decimals = 3,
                            zero.is.missing = TRUE)

    res.tab<-data.frame(test$mid.year,test$n.trees,test$n,test$rbar.tot,test$eps)
    return(res.tab)
  }
}
