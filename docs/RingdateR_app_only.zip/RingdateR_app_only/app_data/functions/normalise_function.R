
normalise<-function(the.data, detrending_select = 1, splinewindow = 21){
  if (!detrending_select %in% c(1:7)){
    stop("Error in normalise(). detrending_select must be a numeric integer from 1 to 7.")

  }
  if (class(splinewindow) != "numeric"){
    stop("Error in normalise(). splinewindow must be a numeric integer")

  }
  if (splinewindow <5 || splinewindow >200){
    stop("Error in normalise(). splinewindow must be a numeric integer from 5 to 500.")

  }
  if (class(the.data) != "data.frame"){
    stop("Error in normalise(). Required data are not a data.frame")

  }
  if (ncol(the.data)<2){
    stop("Error in normalise(). Insufficient data to calculate correlations")

  }
    series_data<-the.data
    no.series<-ncol(the.data)-1
    series_IDs<-c(colnames(the.data))
    series_a<-2 # this is two as the first set of series data should be in the second column
    new<-data.frame(the.data[,1], stringsAsFactors = T) # sets up the data frame to put the detrended data into

    series_a<-2
    tmp_diff<-c()
    det_tmp<-data.frame(the.data[,1])

    for(i in 1:no.series){ # this runs the detrending on all the series data
      if(detrending_select==1){
        A<- series_data[,series_a]
      } else if (detrending_select==2){
        A<- scale(series_data[,series_a], center = T, scale = T)
      } else if (detrending_select==3){
        A<- detrend.series(series_data[,series_a], method = "Spline", nyrs= splinewindow, make.plot = FALSE, pos.slope =TRUE)
      } else if (detrending_select==4){
        A<- detrend.series(series_data[,series_a], method = "ModNegExp", make.plot = FALSE, pos.slope =TRUE)
      } else if (detrending_select==5){
        A<- detrend.series(series_data[,series_a], method = "Friedman", make.plot = FALSE, pos.slope =TRUE)
      } else if (detrending_select==6){
        A<- detrend.series(series_data[,series_a], method = "ModHugershoff", make.plot = FALSE, pos.slope =TRUE)
      } else if (detrending_select==7){
        A<- series_data[,series_a]
        for (j in 1: length(A)){
          tmp<-A[j+1]-A[j]
          tmp_diff<-c(tmp_diff,tmp)
        }
        A<-tmp_diff
        tmp_diff<-c()
      }


      det_tmp<-comb.NA(det_tmp, A, fill = NA)
      series_a<-series_a+1
    }

    series_length = nrow(new)

    det_tmp<-subset(det_tmp, !is.na(det_tmp[,1]))

    colnames(det_tmp)<-series_IDs

    return(det_tmp)

}
